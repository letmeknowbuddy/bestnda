<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>MNS Coaching in Lucknow | Best MNS Classes in Lucknow</title>
<meta name="keyword" content="MNS Coaching in Lucknow | Best MNS Classes in Lucknow" >
<meta name="description" content="Looking for MNS coaching in Lucknow? Look no further! Our expert coaching team is here to help you ace the MNS exam."/>
<link rel="canonical" href="https://shielddefencecollege.com/ssb-coaching-in-lucknow/" />
<meta name="ROBOTS" content="index, follow" />
<META NAME="GOOGLEBOT" content="index, follow" />
<meta name="yahooSeeker" content="index, follow" />
<meta name="msnbot" content="index, follow" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="MNS Coaching in Lucknow | Best MNS Classes in Lucknow" />
<meta property="og:description" content="Looking for MNS coaching in Lucknow? Look no further! Our expert coaching team is here to help you ace the MNS exam." />
<link rel="canonical" href="https://shielddefencecollege.com/ssb-coaching-in-lucknow/" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-04-17T13:34:15+05:30" />
<meta property="og:image" content="https://shielddefencecollege.com/wp-content/uploads/ndabn001.jpg" />
<meta property="og:image:secure_url" content="https://shielddefencecollege.com/wp-content/uploads/ndabn001.jpg" />
<meta property="og:image:width" content="1600" />
<meta property="og:image:height" content="505" />
<meta property="og:image:alt" content="nda coaching in lucknow" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-18T13:50:40+05:30" />
<meta property="article:modified_time" content="2023-04-17T13:34:15+05:30" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="MNS Coaching in Lucknow | Best MNS Classes in Lucknow" />
<meta name="twitter:description" content="Looking for MNS coaching in Lucknow? Look no further! Our expert coaching team is here to help you ace the MNS exam." />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/ndabn001.jpg" />
<meta name="twitter:label1" content="Time to read" />
<meta name="twitter:data1" content="12 minutes" />
<!-- SEO Rank End Here -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section neet_mns_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>NEET + MNS Coaching</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>NEET + MNS</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="courses_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-lg-9 col-md-9 col-sm-12 col-12">
     <div class="courses_target" id="courses_feature">
      <ul>
       <li><a href="#step1">Information</a></li>
       <li><a href="#step2">About</a></li>
       <li><a href="#step3">FEE Details</a></li>
       <li><a href="#step4">Exam Details</a></li>
       <li><a href="#step5">Syllabus</a></li>
      </ul>
     </div>
    <div class="courses_inner" id="step1">
     <h2>NEET + MNS</h2>
     <p>With the government’s focus shifting to ‘one nation, one exam’, the qualifying criteria for BSc (Nursing) course in Military Nursing Services (MNS) 2022 across the six affiliated colleges has been changed. Instead of a separate MNS qualifying exam, the aspirants will now have to qualify for the National Eligibility cum Entrance Test (NEET) to be eligible for the course. Although the suddenness of this decision was confusing at first, stakeholders have accepted this change.</p>     
     <p>Earlier, aspirants had to appear for the MNS written test, which had questions on English, General Knowledge (GK) and Science. This was followed by a panel interview and a medical test. As per the new format, candidates will have to appear for five qualifying rounds.</p>
     <p>Candidates will have to qualify NEET, which will be followed by a Test of General Intelligence and General English, which would be worth 80 marks. The remaining three rounds include an objective-type psychological Assessment Test (PAT), an Interview and medical exam.”</p>
     <p>Shield Defence College, India’s first largest & best defence training Institute trains you with full amenities and a well-structured curriculum to help you ace written examination and conquer your Interview in one go.</p>
    </div>
    <div class="courses_inner" id="step2">
     <h2>MNS (Medical Nursing Services)</h2>
     <p>Shield Defence College’s MNS (Military Nursing Service) course is a comprehensive program designed to help students prepare for the MNS exam, which is a gateway to becoming a commissioned officer in the Indian Army’s Nursing Service. Our program is designed to provide students with a strong foundation in the subjects required for the exam, including biology, physics, chemistry, and English.</p>
     <ul class="dtl_list">
      <li><span>Why should you JOIN NEET+MNS?</span> Shield defence academy provides a comprehensive approach to the students for MNS course</li>
      <li><span>Mock Interviews & Comforting sessions</span> Special focus on their logic capability & logical thinking capability while targeting the MNS SSB Interview & Psychology.</li>
      <li><span>Medical Check up and Counseling</span> Medical Check up & Counseling is conducted to assess their medical norms. Comforting for diet, exercise, yoga etc.</li>
      <li><span>SDC POOL of experts NEET+MNS</span> A platoon of experts in training platoon has rich exposure numerous times in their subject and is devoted to making pupils selectable constantly.</li>
      <li><span>Assignment plan grounded lectures</span> The syllabus has been divided into modules and also from modules to assignments so that you pupil may get clarity at the morning of medication only.</li>
      <li><span>Daily Mock Test</span> Daily Mock Test as per MNS pattern conducted on Saturday to get them adapted with rearmost test trends and their gained score show them the real script of their medication.</li>
      <li><span>SDC Doubt Clearing Sessions</span> Doubt Clearing Sessions after lecture conducted to estimate their retain- capability of the content and modification and query session conducted to enhance their participation for repartee.</li>
      <li><span>Exposure to SSB Interview</span> SSB Interview exposure along with MNS written test handed under SSB Panel so that scholars get ample time to dissect, realize and apply virtually norms of interview and the officer like rates.</li>
      <li><span>Online Gate / App</span> Online Defence test portals give scholars access to a variety of questions & make them ready for test by conducting their test on all India bases. Digital Content make you stay connected indeed.</li>
     </ul>
     
    </div>
    <div class="courses_inner" id="step3">
     <h2>FEE Details</h2>
     <div class="courses_table">
      <table>
       <thead>
         <tr>
          <th>Course</th>
          <th>Duration</th>
          <th>Fees</th>
         </tr>
       </thead>
       <tbody>
        <tr>
         <td>MNS</td>
         <td>One Year</td>
         <td>-</td>
        </tr>
        <tr>
        <td>MNS</td>
         <td>Till Selection</td>
         <td>-</td>
        </tr>
        <tr>
        <td>MNS</td>
         <td>Six Months</td>
         <td>-</td>
        </tr>
        <tr>
        <td>MNS</td>
         <td>Crash Course</td>
         <td>-</td>
        </tr>
       </tbody>
      </table>
     </div>
    </div>
    <div class="courses_inner" id="step4">
     <h2>MNS Written Exam Details</h2>
     <p>Women who possess strength, gentleness, humility, compassion, and resilience have the ability to raise stronger, more courageous, educated, passionate, and rational individuals who can bring honor to their country. The Military Nursing Services (MNS) is an all-women, all-officer corps of the Indian Army, where women officers are considered an integral part of the Armed Forces Medical Services (AFMS). The MNS test is conducted annually by the Directorate General of Medical Services (DGMS) to select female candidates for admission to the four-year B.Sc. (Nursing) course at the Armed Forces Medical Services Colleges of Nursing. The eligibility criteria for the MNS test has changed, and candidates must now pass the National Eligibility cum Entrance Test (NEET) to be eligible for the MNS test.</p>
     <h3>MNS Recruitment Drive:</h3>
     <p><span>Military Nursing Service (MNS) Recruitment Drive:</span></p>
     <h4>Details:</h4>
     <ul class="dtl_list">
      <li><span>Exam Name:</span> MNS – Army BSc. Nursing Exam</li>
      <li><span>Exam Conducting Body: </span> Directorate General of Armed Forces Medical Services (DG-AFMS), Indian Army</li>
      <li><span>Preliminary Phase: </span> NEET Qualified</li>
      <li><span>Preliminary Exam Conducting Body: </span> National Testing Agency (NTA)</li>
      <li><span>Nature of Questions: </span> Objective</li>
      <li><span>Subjects Covered in NEET: </span> Physics, Chemistry, Biology (Botany + Zoology)</li>
      <li><span>Maximum Marks in NEET: </span> 720</li>
      <li><span>Negative Marking: </span> Not Applicable</li>
      <li><span>Eligible Category: </span> Female Only</li>
      <li><span>Marital Status: </span> Unmarried/Divorced/Legally Separated</li>
      <li><span>Educational Qualification: </span> Passed or appearing in 10+2 or equivalent examination with Physics, Chemistry, Biology (Botany & Zoology) and English with not less than 50% aggregate marks.</li>
     </ul>
    </div>
    <div class="courses_inner" id="step5">
     <h2>Syllabus</h2>
     <p>Revised Qualification Requirements for MNS Exam 2023: NEET + MNS Exam Syllabus</p>
     <p>Starting from the year 2023, the qualification requirements for the Military Nursing Service (MNS) exam have been revised for all six affiliated colleges. Instead of a single MNS written test, candidates will now have to pass the National Eligibility cum Entrance Test (NEET) as a prerequisite for moving forward. The new syllabus for MNS now consists of five testing rounds, including the NEET exam.</p>
    </div>
   </div>

   <div class="col-lg-3 col-md-3 col-sm-12 col-12">
   
    <?php echo $__env->make('include.side-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </div>
  </div>
 </div>
</div>
<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>

<!-- <script>
window.onscroll = function() {myFunction()};
var courses_target = document.getElementById("courses_feature");
var sticky = courses_target.offsetTop;
function myFunction() {
  if (window.pageYOffset > sticky) {
    courses_target.classList.add("sticky");
  } else {
    courses_target.classList.remove("sticky");
  }
}
</script> -->
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/neet-mns-coaching-in-lucknow.blade.php ENDPATH**/ ?>