
<?php
$webmaster_update  = DB::Table('webmaster_update')->where('id', 1)->first();
$analytics_update  = DB::Table('analytics_update')->where('id', 1)->first();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>Best NDA Coaching in Lucknow | NDA Training Institute in Lucknow</title>
<meta content="Best NDA Coaching in Lucknow | NDA Training Institute in Lucknow" name="keywords">
<meta content="Shield Defence College is best NDA coaching in Lucknow. Our Team is Focused on Providing Best NDA Training that trains the cadets to be DEXTEROUS in basic soldiering skills." name="description">
<link rel="canonical" href="https://shielddefencecollege.com/">
<link rel="amphtml" href="https://shielddefencecollege.com/">
<link rel="alternate" href="https://shielddefencecollege.com/" hreflang="en-us">
<meta name="google-site-verification" content="<?php echo $webmaster_update->google ?>" />
<meta name="yandex-verification" content="<?php echo $webmaster_update->yandex ?>" />
<!-- <meta name="msvalidate.01" content="<?php echo $webmaster_update->pintrest ?>" /> -->
<meta name="ROBOTS" content="INDEX, FOLLOW">
<META NAME="GOOGLEBOT" content="INDEX, FOLLOW">
<meta name="yahooSeeker" content="index, follow">
<meta name="msnbot" content="index, follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Shield Defence College">
<meta property="og:title" content="Best NDA Coaching in Lucknow | NDA Training Institute in Lucknow" />
<meta property="og:description" content="Shield Defence College is best NDA coaching in Lucknow. Our Team is Focused on Providing Best NDA Training that trains the cadets to be DEXTEROUS in basic soldiering skills." />
<meta property="og:url" content="https://shielddefencecollege.com/" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:image" content="/" />
<meta property="og:image:secure_url" content="/" />
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="600" />
<meta property="og:image:alt" content="NDA Coaching in Lucknow" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-04T00:28:23+05:30" />
<meta property="article:modified_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:ttl" content="345600">
<meta property="fb:profile_id" content="/">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="/">
<meta name="twitter:creator" content="/">
<meta name="twitter:title" content="Best NDA Coaching in Lucknow | NDA Training Institute in Lucknow" />
<meta name="twitter:description" content="Shield Defence College is best NDA coaching in Lucknow. Our Team is Focused on Providing Best NDA Training that trains the cadets to be DEXTEROUS in basic soldiering skills." />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/Shield-Defence-Logo-3.jpg" />
<meta name="twitter:label1" content="Written by" />
<meta name="twitter:data1" content="Sdacollege" />
<meta name="twitter:label2" content="Time to read" />
<meta name="twitter:data2" content="1 minute" />
<meta property="og:updated_time" content="2021-01-06T13:49:21">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" >
<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
<?php echo $analytics_update->header; ?>
</head>
<body>
<?php echo $analytics_update->body; ?>

 <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel" autoplay>
 <div class="carousel-inner">
  <div class="carousel-item active">
   <img src="<?php echo e(asset('website/images/banner/banner_1.webp')); ?>" class="d-block w-100" alt="...">
   <div class="h_banner_content">
    <h1>Join SDC and Realize Your <br> Dream of Serving the Nation</h1>
    <p>Join Shield Defence College and take the first step towards a rewarding career in defence. Our top-notch training <br> programs will help you realize your dream of serving the nation. Enroll now!</p>
    <a href="#!" class="aply_btn">Apply Now</a>
   </div>
  </div>
  <div class="carousel-item">
   <img src="<?php echo e(asset('website/images/banner/banner_2.webp')); ?>" class="d-block w-100" alt="...">
   <div class="h_banner_content">
    <h2>SDC Your Pathway to a <br> Rewarding Career in Defence</h2>
    <p>Unlock a rewarding career in defence with Shield Defence College. Our industry-leading training programs and experienced <br> faculty offer the perfect pathway to success. Join us today!</p>
    <a href="#!" class="aply_btn">Apply Now</a>
   </div>
  </div>
  <div class="carousel-item">
   <img src="<?php echo e(asset('website/images/banner/banner_3.webp')); ?>" class="d-block w-100" alt="...">
   <div class="h_banner_content">
    <h2>Start Your Journey towards a Thrilling <br> Career in Defence with SDC</h2>
    <p>Begin your journey to a thrilling career in defence with Shield Defence College. Our top-notch training programs and experienced <br> faculty will prepare you for success. Enroll now!</p>
    <a href="#!" class="aply_btn">Apply Now</a>
   </div>
  </div>
 </div>
 <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
  <span aria-hidden="true"><i class="fas fa-angle-left"></i></span>
 </button>
 <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
  <span aria-hidden="true"><i class="fas fa-angle-right"></i></span>
 </button>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="home_about_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-7">
    <div class="h_abt_info">
     <h2 class="main_heading">Welcome To The <span>Best NDA Coaching In Lucknow</span>!</h2>
     <p>India’s first largest private defence institute in Lucknow is dedicated to providing top-notch training and resources to help defence aspirants succeed in their pursuit of a career in the <strong>Indian Armed Forces</strong>.</p>
     <p>The nation’s first largest initiative – <strong>SDC</strong> is a premier institute with a residential campus offering integrated programmes like Foundation Batches for <strong>NDA</strong> (For 8th and 10th qualified students), <strong>NDA</strong> (for 12th pass), SSB Interview, <strong>CDS, AFCAT</strong> and <strong>MNS</strong> under the guidance of Ex- defence officers who served in various SSB boards, defence mentors capable of bringing umpteen changes to your personalities and our highly qualified and experienced faculty members are committed to providing comprehensive and personalized coaching helping them to ace their written examinations and conquer SSB interviews</p>
    </div>
   </div>
   <div class="col-md-5">
    <div class="h_abt_img">
     <img src="<?php echo e(asset('website/images/h_abt.png')); ?>" alt="Shield Defence College" class="img-fluid">
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- About Us Section End Here -->

<div class="courses_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-lg-9 col-md-9 col-sm-12 col-12">
    <div class="courses_target">
     <div class="courses_inner" id="step1">
     <h2>Why Join Centurion Defence Academy?</h2>
     <p>Shield Defence college provides an NDA foundation Program designed specifically for students in the 11th and 12th grades who aspire to join the Indian Armed Forces. The course is aimed at providing students with a comprehensive understanding of the NDA examination pattern and syllabus, as well as improving their knowledge and skills in subjects like Mathematics, Physics, Chemistry, English, and General Knowledge.</p>
     <h3>Join NDA Foundation Course In Lucknow</h3>
     <p>Shield Defence college provide a strong foundation in subjects like Mathematics, Physics, Chemistry, English, and General Knowledge, that are the key subjects for the NDA entrance examination. We have a detail oriented approach to cover the conceptual topics and analytical approach to make you ready for the NDA written exam.</p>
     <h3>Why Should You Join NDA Foundation Course</h3>
     <p>Our well designed curriculum of the NDA Foundation Course covers the entire syllabus of the NDA entrance exam. The course includes regular classroom lectures, doubt clearing sessions, practice tests, and mock exams to help students improve their performance and score well in the exam. Alongside boosting the confidence of students it also provides a solid way to have a strong grip over concepts. Shield Defence college is a perfect go to destination for NDA Foundation College in Lucknow which prepares students with result oriented, committed and ethics based training.</p>
    </div>
    <div class="courses_inner" id="step2">
     <h2>Also, We are Providing with the Following Services to Students:</h2>
      <ol>
       <li>Our study materials are designed according to the latest exam pattern to ensure students are well-prepared.</li>
       <li>We use a biometric attendance tracking system to accurately record attendance and monitor student progress.</li>
       <li>We regularly meet with guardians to discuss student performance and address any concerns they may have. </li>
       <li>We offer both online and offline mock tests to help students practice and prepare for exams.</li>
       <li>Our classes feature motivational lectures by specialists and retired Defence officers to inspire and encourage students.</li>
       <li>Our experienced and well-qualified faculties from India deliver engaging and informative lectures.</li>
       <li>We provide a doubt removal counter facility to ensure students can clarify their doubts and enhance their understanding.</li>
       <li>We offer special attention and support to slow learners to help them succeed academically.</li>
      </ol>
    </div>
    <div class="courses_inner" id="step3">
     <h2>Eligibility Criteria for Joining the NDA Foundation Course</h2>
     <p>Anyone  who has passed class 10th or Class 11th are eligible to join the course to get better prepared for the boards as well as for NDA under the guidance of the Ex- Defence Observers and Officers. The study accoutrements  are designed after proper  exploration and it’s proved that the study accoutrements are  far than enough for the NDA Written test and class 12th board etc.</p>
     <p>Also, there are some essential criterias for students to join the NDA course</p>
     <p><span>Age: </span>The candidate must be between 15.5 to 19 years of age.</p>
     <p><span>Educational Qualification: </span>The candidate must have completed their 10+2 (or equivalent) education from a recognized board.</p>
     <p><span>Nationality: </span>The candidate must be an Indian citizen or a subject of Bhutan or Nepal.</p>
     <p><span>Physical Standards: </span>The candidate must be physically fit and meet the prescribed physical standards.</p>
     <p><span>Marital Status: </span>Male &amp; female candidates are eligible to apply.</p>
     <p>It is important to note that these eligibility criteria may vary from time to time, and interested candidates should refer to the official website of the National Defence Academy for the most up-to-date information.</p>
     <h3>Selection Procedure for NDA</h3>
     <ul class="dtl_list">
      <li>Written Exam conducted by UPSC</li>
      <li>SSB Interview conducted by Service Selection Boards of Army/Navy and Air Force</li>
      <li>Medical Examination</li>
     </ul>
     <h3>Exam Schedule for NDA</h3>
     <ul class="dtl_list">
      <li>NDA 1 in April</li>
      <li>NDA 2 in September</li>
     </ul>
     <h4>Shield Defence College Classroom Training</h4>
     <p>Shield defence college Lucknow prioritizes to train the students in such a manner to clear the exam. Here are the essential key features of our classroom training.</p>
     <ul>
      <li>Regular Classes</li>
      <li>Lectures by experienced</li>
      <li>Doubt removal sessions</li>
      <li>Special Attention on slow learner students</li>
      <li>Study materials designed by Experts</li>
      <li>Online and Offline Mock Tests</li>
      <li>Career guidance by Ex-Defence Officers</li>
     </ul>
    </div>
    <div class="courses_inner" id="step4">
     <h2>Duration of the NDA Course</h2>
     <p>The National Defence Academy (NDA) Foundation Course is a training program designed to prepare young individuals for entry into the Indian Armed Forces. The duration of the NDA Foundation Course is generally six months. During this period, candidates undergo rigorous training in various subjects, including mathematics, physics, chemistry, and general knowledge. The training also includes physical fitness exercises and drill, which are essential for building the endurance and stamina required for a career in the armed force</p>
     <p>After successful completion of the NDA Foundation Course, candidates are eligible to appear for the NDA entrance examination, which is conducted twice a year by the Union Public Service Commission (UPSC). The NDA entrance examination consists of a written test followed by an interview by the Services Selection Board (SSB), and successful candidates can then join the Indian Army, Navy or Air Force.</p>
     <h3>The Teaching Systems at NDA Foundation:-</h3>
     <p><span>Academic Education: </span>This cores encapsulates the whole syllabus includig  Physics, Chemistry, Mathematics, English and General Studies (as per their time suitability) to upscale their performance in board exams alongside NDA.</p>
     <p><span>Competitive Education: </span>NDA exams takes place twice every year. To secure the result in NDA, we give specialized training with competitive concept from class 11th &amp; 12th.</p>
    </div>
    </div>
   </div>
   <div class="col-lg-3 col-md-3 col-sm-12 col-12">
    <div class="side_form">
     <h6>Enquiry Form</h6>
     <form action="/">
      <div class="row">
       <div class="col-lg-12 col-md-12 col-sm-6 col-12">
        <input type="text" name="name" placeholder="Enter Your Name" class="form-control">
       </div>
       <div class="col-lg-12 col-md-12 col-sm-6 col-12">
        <input type="number" name="number" placeholder="Enter Mobile No." class="form-control">
       </div>
       <div class="col-lg-12 col-md-12 col-sm-6 col-12">
        <input type="text" name="city" placeholder="Enter Your City" class="form-control">
       </div>
       <div class="col-lg-12 col-md-12 col-sm-6 col-12">
        <input type="text" name="course" placeholder="Course*" value="NDA" disabled="" class="form-control">
       </div>
       <div class="col-lg-12 col-md-12 col-sm-6 col-12">
        <button type="submit" name="submit" class="form-control mb-0">Submit</button>
       </div>
      </div>
     </form>
    </div>   
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!--  Section End Here -->

<div class="selected_students equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="sub_head">
     <h2>Our Selections <span>in CDS</span></h2>
    </div>
   </div>
   <div class="col-md-12">
    <div class="owl-carousel select_student">
     <div class="item">
      <div class="f_img">
       <img src="website/images/gallery/student_1.webp" alt="Lakshya Chaudhary" class="img-fluid">
      </div>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="website/images/gallery/student_2.webp" alt="Supriya Tiwari" class="img-fluid">
      </div>
     </div>
     <div class="item">
      <div class="f_img">
       <img src="website/images/gallery/student_3.webp" alt="Abhinav Singh" class="img-fluid">
      </div>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="website/images/gallery/student_4.webp" alt="Vaibhav Raj" class="img-fluid">
      </div>
     </div>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Our Facility Section End Here -->

<div class="gallery_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="sub_head">
     <h2>Our <span>Gallery</span></h2>
    </div>
   </div>
  </div>
 </div>
 <div class="row gall_row">
  <div class="col-md-3 col-sm-4 col-6 gallery_col">
   <div class="gal_inner">
    <a href="website/images/gallery/g_photo1.webp">
     <img src="website/images/gallery/g_photo1.webp" alt="Gallery Pic 1">
    </a>
   </div>
  </div>
  <div class="col-md-3 col-sm-4 col-6 gallery_col">
   <div class="gal_inner">
    <a href="website/images/gallery/g_photo2.webp">
     <img src="website/images/gallery/g_photo2.webp" alt="Gallery Pic 2">
    </a>
   </div>
  </div>
  <div class="col-md-3 col-sm-4 col-6 gallery_col">
   <div class="gal_inner">
    <a href="website/images/gallery/g_photo3.webp">
     <img src="website/images/gallery/g_photo3.webp" alt="Gallery Pic 3">
    </a>
   </div>
  </div>
  <div class="col-md-3 col-sm-4 col-6 gallery_col">
   <div class="gal_inner">
    <a href="website/images/gallery/g_photo4.webp">
     <img src="website/images/gallery/g_photo4.webp" alt="Gallery Pic 4">
    </a>
   </div>
  </div>
  <div class="col-md-3 col-sm-4 col-6 gallery_col">
   <div class="gal_inner">
    <a href="website/images/gallery/g_photo5.webp">
     <img src="website/images/gallery/g_photo5.webp" alt="Gallery Pic 5">
    </a>
   </div>
  </div>
  <div class="col-md-3 col-sm-4 col-6 gallery_col">
   <div class="gal_inner">
    <a href="website/images/gallery/g_photo6.webp">
     <img src="website/images/gallery/g_photo6.webp" alt="Gallery Pic 6">
    </a>
   </div>
  </div>
  <div class="col-md-3 col-sm-4 col-6 gallery_col">
   <div class="gal_inner">
    <a href="website/images/gallery/g_photo7.webp">
     <img src="website/images/gallery/g_photo7.webp" alt="Gallery Pic 7">
    </a>
   </div>
  </div>
  <div class="col-md-3 col-sm-4 col-6 gallery_col">
   <div class="gal_inner">
    <a href="website/images/gallery/g_photo8.webp">
     <img src="website/images/gallery/g_photo8.webp" alt="Gallery Pic 8">
    </a>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Gallery Section End Here -->

<div class="coaching_section equal_space">
 <div class="container">
 <div class="row">
  <div class="col-md-7 col-sm-6 col-12">
   <div class="coaching_info">
    <h2>India's Best NDA Coaching Academy</h2>
    <h3>Teaching and Training on the Pattern of Military School</h3>
    <h4>OFFLINE Coaching</h4>
    <span>+10k Selections in Defence Exams</span>
   </div>
  </div>
  <div class="col-md-5 col-sm-6 col-12">
   <div class="coaching_form">
    <h3>Get "India's Best NDA Coaching Academy"</h3>
    <p>AFPI EXPERT: Get all your queries answered</p>
    <div class="coac_form">
      <form action="/">
       <div class="row">
        <div class="col-md-12 col-sm-12 col-12">
         <div class="form-group mb-3">
          <input type="text" class="form-control" name="name" placeholder="Enter Name*">
         </div>
        </div>
        <div class="col-md-12 col-sm-12 col-12">
         <div class="form-group mb-3">
          <input type="text" class="form-control" name="number" placeholder="Enter Ph. Number*" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" pattern="[0-9]{10,12}" minlength="10" maxlength="10" required="">
         </div>
        </div>
        <div class="col-md-12 col-sm-12 col-12">
         <div class="form-group mb-3">
          <input type="text" class="form-control" name="city" placeholder="Enter Your City*" required="">
         </div>
        </div>
        <div class="col-md-12 col-sm-12 col-12">
         <div class="form-group mb-3">
          <input type="text" class="form-control" name="course" placeholder="Courses*" value="NDA" disabled="" required="">
          <!-- <select class="form-control" placeholder="--Select Courses --" name="course">
           <option value="--Select Courses --">--Select Courses --</option>
           <option value="NDA Foundation">NDA Foundation</option>
           <option value="NDA">NDA</option>
           <option value="SSB Interview">SSB Interview</option>
           <option value="CDS">CDS</option>
           <option value="AFCAT">AFCAT</option>
           <option value="NEET+MNS">NEET+MNS</option>
          </select> -->
         </div>
        </div>
        <div class="col-md-12">
         <div class="form-group">
          <button>Apply Now</button>
         </div>
        </div>
       </div>
      </form>
     </div>
   </div>
  </div>
 </div>
 </div>
</div>

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
<script>
 $('.select_student').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    autoplay:true,
    responsive:{
        0:{
            items:1
        },
        400:{
            items:1
        },
        576:{
            items:2
        },
        767:{
            items:3
        },
        1200:{
            items:4
        }
    }
})
</script>
<script>
  $(".number").counterUp({time:5000});
</script>
<script>
 <?php if(Session::has('message')): ?>
 var type = "<?php echo e(Session::get('alert-type','info')); ?>"
 switch(type){
    case 'info':
    toastr.info(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'success':
    toastr.success(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'warning':
    toastr.warning(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'error':
    toastr.error(" <?php echo e(Session::get('message')); ?> ");
    break; 
 }
 <?php endif; ?> 
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\mohd\bestndacoachinginlucknow\resources\views/index.blade.php ENDPATH**/ ?>