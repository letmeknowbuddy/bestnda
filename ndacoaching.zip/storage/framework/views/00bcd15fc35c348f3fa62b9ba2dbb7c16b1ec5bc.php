<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>Online Registration | Shield Defence College</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<META NAME="GOOGLEBOT" content="NOINDEX, NOFOLLOW" />
<meta name="yahooSeeker" content="noindex, nofollow" />
<meta name="msnbot" content="noindex, nofollow" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="online-registration equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <p><span>Note</span> :- NO REFUND of registration fees is allowed under any circumstances.</p>
   </div>
   <div class="col-md-12">
    <div class="registration_inner">
     <h1 class="text-center main_heading">Online Registration</h1>
     <form method="POST" action="<?php echo e(route('admin.onlinesave')); ?>">
      <?php echo csrf_field(); ?>
      <div class="row">
       <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <select class="form-control" placeholder="--Select Courses --" name="course">
         <option value="--Select Courses --">--Select Courses --</option>
         <option value="NDA Foundation">NDA Foundation</option>
         <option value="NDA">NDA</option>
         <option value="SSB Interview">SSB Interview</option>
         <option value="CDS">CDS</option>
         <option value="AFCAT">AFCAT</option>
         <option value="NEET+MNS">NEET+MNS</option>
        </select>
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="text" name="c_name" class="form-control" placeholder="Enter Your Name*" required="">
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="text" name="fa_name" class="form-control" placeholder="Enter Father’s Name*" required="">
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="text" name="mother_name" class="form-control" placeholder="Enter Mother's Name*" required="">
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="text" name="number" class="form-control" placeholder="Enter Mobile No.*" required="">
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="mail" name="email" class="form-control" placeholder="Enter E-Mail*" required="">
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="date" name="dob" class="form-control" placeholder="Date of Birth" required="">
       </div>
       <div class="col-lg-6 col-md-6 col-sm-12 col-12">
        <textarea name="corr_address" class="form-control" id="" cols="30" rows="5" placeholder="Correspondence address*"></textarea>
       </div>
       <div class="col-lg-6 col-md-6 col-sm-12 col-12">
        <textarea name="per_address" class="form-control" id="" cols="30" rows="5" placeholder="Permanent address*"></textarea>
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="text" name="city" class="form-control" placeholder="Enter Your City*" required="">
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="text" name="pincode" class="form-control" placeholder="Enter Your Pincode*" required="">
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <select class="form-control" placeholder="--Select State --" name="state">
         <option value="--Select State --">--Select State --</option>
         <option value="Andhra Pradesh">Andhra Pradesh</option>
         <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
         <option value="Arunachal Pradesh">Arunachal Pradesh</option>
         <option value="Assam">Assam</option>
         <option value="Bihar">Bihar</option>
         <option value="Chandigarh">Chandigarh</option>
         <option value="Chhattisgarh">Chhattisgarh</option>
         <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
         <option value="Daman and Diu">Daman and Diu</option>
         <option value="Delhi">Delhi</option>
         <option value="Lakshadweep">Lakshadweep</option>
         <option value="Puducherry">Puducherry</option>
         <option value="Goa">Goa</option>
         <option value="Gujarat">Gujarat</option>
         <option value="Haryana">Haryana</option>
         <option value="Himachal Pradesh">Himachal Pradesh</option>
         <option value="Jammu and Kashmir">Jammu and Kashmir</option>
         <option value="Jharkhand">Jharkhand</option>
         <option value="Karnataka">Karnataka</option>
         <option value="Kerala">Kerala</option>
         <option value="Madhya Pradesh">Madhya Pradesh</option>
         <option value="Maharashtra">Maharashtra</option>
         <option value="Manipur">Manipur</option>
         <option value="Meghalaya">Meghalaya</option>
         <option value="Mizoram">Mizoram</option>
         <option value="Nagaland">Nagaland</option>
         <option value="Odisha">Odisha</option>
         <option value="Punjab">Punjab</option>
         <option value="Rajasthan">Rajasthan</option>
         <option value="Sikkim">Sikkim</option>
         <option value="Tamil Nadu">Tamil Nadu</option>
         <option value="Telangana">Telangana</option>
         <option value="Tripura">Tripura</option>
         <option value="Uttar Pradesh">Uttar Pradesh</option>
         <option value="Uttarakhand">Uttarakhand</option>
         <option value="West Bengal">West Bengal</option>
        </select>
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <select class="form-control" placeholder="--Select Qualification --" name="qualification">
         <option value="--Select Qualification --">--Select Qualification --</option>
         <option value="8th Passed">8th Passed</option>
         <option value="9th Passed">9th Passed</option>
         <option value="10th Passed">10th Passed</option>
         <option value="11th Passed">11th Passed</option>
         <option value="12th Passed">12th Passed</option>
         <option value="12th Passed with PCM">12th Passed with PCM</option>
        </select>
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="text" name="board" class="form-control" placeholder="Enter Your Board Name*" required="">
       </div>
       <div class="col-lg-4 col-md-4 col-sm-6 col-12">
        <input type="text" name="percentage" class="form-control" placeholder="Enter Your Percentage*" required="">
       </div>
       <div class="col-lg-6 col-md-6 col-sm-6 col-12">
        <input type="text" name="passing_year" class="form-control" placeholder="Year of Passing*" required="">
       </div>
       <div class="col-lg-6 col-md-6 col-sm-6 col-12">
        <input type="text" name="medium" class="form-control" placeholder="Medium*" required="">
       </div>
       <div class="col-lg-6 col-md-6 col-sm-6 col-12">
        <input type="text" name="currency" class="form-control" placeholder="Currency*" value="INR" readonly="">
       </div>
       <div class="col-lg-6 col-md-6 col-sm-6 col-12">
        <input type="text" name="reg_amount" class="form-control" placeholder="Registration Amount*" value="₹ 5000" readonly="" required="">
       </div>
       <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <button type="submit" value="submit" class="submit_btn">Submit</button>
       </div>
      </div>
     </form>
    </div>
   </div>
  </div>
 </div>
</div>


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/online-registration.blade.php ENDPATH**/ ?>