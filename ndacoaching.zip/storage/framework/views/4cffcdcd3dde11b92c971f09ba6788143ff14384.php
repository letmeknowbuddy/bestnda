<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>Vikram Batra Auditorium | Shield Defence College</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<META NAME="GOOGLEBOT" content="NOINDEX, NOFOLLOW" />
<meta name="yahooSeeker" content="noindex, nofollow" />
<meta name="msnbot" content="noindex, nofollow" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section auditorium_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>Vikram Batra Auditorium</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Vikram Batra Auditorium</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="normal_content">
 <div class="container">
  <div class="row">
   <div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="nor_cont_inner">
     <h2>Vikram Batra Auditorium:</h2>
     <p>Named after one of the bravest officers who showed unmatched valor on the battlefield, we have an auditorium, to conduct various activities and help the student develop presentation skills, public speaking, and organizing skills.</p>
     <P>Welcome to the Shield Defence College Auditorium! This state-of-the-art facility is designed to host a variety of events, including lectures, seminars, presentations, workshops, and other academic and professional gatherings related to defence institute. Our auditorium is equipped with modern audiovisual technology and comfortable seating to provide an optimal learning and presentation experience.</p>
     <h3>Facilities and Features:</h3>
     <ul>
      <li><span>Seating Capacity:</span> Our auditorium is designed to accommodate a large audience, with comfortable seating arranged in a tiered format to ensure clear visibility for all attendees.</li>
      <li><span>Audiovisual Technology:</span> Our coaching institute’s auditorium is equipped with advanced audiovisual technology, including high-quality sound systems, projectors, screens, and lighting, to facilitate effective presentations, lectures, and multimedia content delivery.</li>
      <li><span>Stage and Podium:</span> The auditorium features a stage with a podium for speakers and presenters, providing a professional platform for delivering lectures, speeches, and presentations.</li>
      <li><span>Multimedia Connectivity:</span> The auditorium is equipped with multimedia connectivity options, including audio and video inputs, to connect laptops, tablets, or other devices for presentations, demonstrations, and discussions.</li>
      <li><span>Acoustics:</span> Our auditorium is designed with optimal acoustics to ensure clear audio throughout the space, allowing speakers and presenters to be heard clearly by all attendees.</li>
      <li><span>Accessibility:</span> The auditorium is designed to be accessible for individuals with disabilities, with features such as wheelchair ramps, reserved seating, and other accommodations to ensure inclusivity and equal access for all.</li>
      <li><span>Professional Lighting:</span> The auditorium features professional lighting systems, including stage lights and ambient lighting, to create a visually appealing and engaging environment for presentations and events.</li>
      <li><span>Event Support:</span> Our defence academy auditorium is supported by dedicated staff who can assist with event planning, setup, and technical support, ensuring smooth and successful events.</li>
     </ul>
     <h3>Auditorium Usage Guidelines:</h3>
     <p>To ensure the smooth operation of the auditorium, we have specific guidelines for usage, including:</p>
     <ul>
      <li><span>Reservation and Scheduling:</span> The auditorium may require reservation and scheduling for events. Users are encouraged to follow the designated process for booking the auditorium for their events.</li>
      <li><span>Technical Assistance:</span> Technical assistance may be provided by the auditorium staff for setup, audiovisual support, and troubleshooting during events.</li>
      <li><span>Equipment Usage:</span> Users are expected to handle the audiovisual equipment and other facilities in the auditorium with care, and follow any instructions provided by the auditorium staff to ensure proper usage.</li>
      <li><span>Event Management:</span> Users are responsible for managing their events in the auditorium, including setup, cleanup, and adhering to college policies and guidelines.i</li>
      <li><span>Compliance with Policies:</span> Users are required to comply with all applicable college policies, including those related to event management, audiovisual equipment usage, and code of conduct.</li>
     </ul>
     <p>State-of-the-art Computers: Our computer lab is equipped with the latest hardware, including high-performance desktop computers and servers, optimized for demanding computational tasks.</p>
     <ul>
      <li>We provide access to a wide range of specialized software, including cybersecurity tools, data analysis software, military simulations, and strategic planning software, to support research and learning in defence-related disciplines.</li>
      <li>Our lab is connected to a high-speed internet network, enabling students and faculty to access online resources, conduct research, and collaborate with experts from around the world.</li>
      <li>As the top defence academy in Lucknow, we prioritize cybersecurity. Our lab is equipped with advanced security measures to protect against cyber threats, including firewalls, antivirus software, and regular security updates, to ensure a safe computing environment.</li>
      <li>Our lab has dedicated technical support staff who are available to assist with troubleshooting, software installations, and general technical assistance to ensure the smooth operation of the lab.</li>
      <li>The computer lab serves as a hub for research activities related to defence and national security. Students and faculty can leverage the lab’s resources to conduct cutting-edge research, analyze data, and develop innovative solutions for defence challenges.</li>
      <li>The lab also provides collaborative spaces where students and faculty can work together on group projects, discuss research ideas, and engage in interdisciplinary discussions related to defence and national security.</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Normal Content Section End Here -->


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/vikram-batra-auditorium.blade.php ENDPATH**/ ?>