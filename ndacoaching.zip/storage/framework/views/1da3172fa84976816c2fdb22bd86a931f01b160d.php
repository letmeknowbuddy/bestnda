<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.webp">
<title>Shield Defence College</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" >
<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>
 <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel" autoplay>
 <div class="carousel-inner">
  <div class="carousel-item active">
   <img src="<?php echo e(asset('website/images/banner/banner_1.webp')); ?>" class="d-block w-100" alt="...">
   <div class="h_banner_content">
    <h1>Join SDC and Realize Your <br> Dream of Serving the Nation</h1>
    <p>Join Shield Defence College and take the first step towards a rewarding career in defence. Our top-notch training <br> programs will help you realize your dream of serving the nation. Enroll now!</p>
    <a href="#!" class="aply_btn">Apply Now</a>
   </div>
  </div>
  <div class="carousel-item">
   <img src="<?php echo e(asset('website/images/banner/banner_2.webp')); ?>" class="d-block w-100" alt="...">
   <div class="h_banner_content">
    <h2>SDC Your Pathway to a <br> Rewarding Career in Defence</h2>
    <p>Unlock a rewarding career in defence with Shield Defence College. Our industry-leading training programs and experienced <br> faculty offer the perfect pathway to success. Join us today!</p>
    <a href="#!" class="aply_btn">Apply Now</a>
   </div>
  </div>
  <div class="carousel-item">
   <img src="<?php echo e(asset('website/images/banner/banner_3.webp')); ?>" class="d-block w-100" alt="...">
   <div class="h_banner_content">
    <h2>Start Your Journey towards a Thrilling <br> Career in Defence with SDC</h2>
    <p>Begin your journey to a thrilling career in defence with Shield Defence College. Our top-notch training programs and experienced <br> faculty will prepare you for success. Enroll now!</p>
    <a href="#!" class="aply_btn">Apply Now</a>
   </div>
  </div>
 </div>
 <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
  <span aria-hidden="true"><i class="fas fa-angle-left"></i></span>
 </button>
 <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
  <span aria-hidden="true"><i class="fas fa-angle-right"></i></span>
 </button>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="home_about_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-7">
    <div class="h_abt_info">
     <h2 class="main_heading">Welcome To The <span>Shield Defence College</span>!</h2>
     <p>India’s first largest private defence institute in Lucknow is dedicated to providing top-notch training and resources to help defence aspirants succeed in their pursuit of a career in the <strong>Indian Armed Forces</strong>.</p>
     <p>The nation’s first largest initiative – <strong>SDC</strong> is a premier institute with a residential campus offering integrated programmes like Foundation Batches for <strong>NDA</strong> (For 8th and 10th qualified students), <strong>NDA</strong> (for 12th pass), SSB Interview, <strong>CDS, AFCAT</strong> and <strong>MNS</strong> under the guidance of Ex- defence officers who served in various SSB boards, defence mentors capable of bringing umpteen changes to your personalities and our highly qualified and experienced faculty members are committed to providing comprehensive and personalized coaching helping them to ace their written examinations and conquer SSB interviews</p>
     <a href="#!" class="aply_dark_btn">Apply Now</a>
    </div>
   </div>
   <div class="col-md-5">
    <div class="h_abt_img">
     <img src="<?php echo e(asset('website/images/h_abt.png')); ?>" alt="Shield Defence College" class="img-fluid">
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- About Us Section End Here -->

<div class="home_pillars_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <h3 class="main_heading text-center">Our Pillars <span>of Strength</span></h3>
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Provident illo ipsam fugit expedita.</p>
   </div>
  </div>
  <div class="row">
   <div class="col-md-4 col-sm-6 col-12">
    <div class="h_pillars_inner">
     <div class="h_pillars_img">
      <img src="<?php echo e(asset('website/images/chairman.png')); ?>" alt="Shri Brijbhushan Rajput" class="img-fluid">
     </div>
     <h4>Chairman</h4>
     <p>Shri Brijbhushan Rajput</p>
    </div>
   </div>
   <div class="col-md-4 col-sm-6 col-12">
    <div class="h_pillars_inner">
     <div class="h_pillars_img">
      <img src="<?php echo e(asset('website/images/principal.png')); ?>" alt="Capt. RJ Pandey" class="img-fluid">
     </div>
     <h4>Principal</h4>
     <p>Capt. RJ Pandey</p>
    </div>
   </div>
   <div class="col-md-4 col-sm-6 col-12">
    <div class="h_pillars_inner">
     <div class="h_pillars_img">
      <img src="<?php echo e(asset('website/images/founder.png')); ?>" alt="Mr. Shivam Shukla" class="img-fluid">
     </div>
     <h4>Founder</h4>
     <p>Mr. Shivam Shukla</p>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Our Pillars Section End Here -->

<div class="home_our_facility equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <h3 class="main_heading text-center">Our <span>Facilities</span></h3>
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Provident illo ipsam fugit expedita.</p>
   </div>
   <div class="col-md-12">
    <div class="owl-carousel h_facility_list">
     <div class="item">
      <div class="f_img">
       <img src="<?php echo e(asset('website/images/facility/university.png')); ?>" alt="Highly Atmosphere of Defence">
      </div>
      <p>Highly Atmosphere of Defence</p>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="<?php echo e(asset('website/images/facility/running_track.png')); ?>" alt="Largest GTO Ground">
      </div>
      <p>Largest GTO Ground</p>
     </div>
     <div class="item">
      <div class="f_img">
       <img src="<?php echo e(asset('website/images/facility/swimming_pool.png')); ?>" alt="Swimming Pool">
      </div>
      <p>Swimming Pool</p>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="<?php echo e(asset('website/images/facility/shooting.png')); ?>" alt="Shooting">
      </div>
      <p>Shooting</p>
     </div>
     <div class="item">
      <div class="f_img">
       <img src="<?php echo e(asset('website/images/facility/horse_riding.png')); ?>" alt="Horse Riding">
      </div>
      <p>Horse Riding</p>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="website/images/facility/boxing.png" alt="Boxing">
      </div>
      <p>Boxing</p>
     </div>
     <div class="item">
      <div class="f_img">
       <img src="<?php echo e(asset('website/images/facility/games.png')); ?>" alt="Games">
      </div>
      <p>Games</p>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="<?php echo e(asset('website/images/facility/sports.png')); ?>" alt="Sports">
      </div>
      <p>Sports</p>
     </div>
     <div class="item">
      <div class="f_img">
       <img src="<?php echo e(asset('website/images/facility/gym.png')); ?>" alt="Gym">
      </div>
      <p>Gym</p>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="<?php echo e(asset('website/images/facility/c_lab.png')); ?>" alt="Computer Lab">
      </div>
      <p>Computer Lab</p>
     </div>
     <div class="item">
      <div class="f_img">
       <img src="<?php echo e(asset('website/images/facility/physical_training.png')); ?>" alt="Drill & Physical Training">
      </div>
      <p>Drill & Physical Training</p>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="<?php echo e(asset('website/images/facility/library.png')); ?>" alt="Library">
      </div>
      <p>Library</p>
     </div>
     <div class="item">
      <div class="f_img">
       <img src="<?php echo e(asset('website/images/facility/mess_campus.png')); ?>" alt="Mess With in Campus">
      </div>
      <p>Mess With in Campus</p>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="<?php echo e(asset('website/images/facility/accommodation_campus.png')); ?>" alt="Accommodation With in Campus">
      </div>
      <p>Accommodation With in Campus</p>
     </div>
     <div class="item">
      <div class="f_img">
       <img src="<?php echo e(asset('website/images/facility/smart_class.png')); ?>" alt="Smart Classrooms">
      </div>
      <p>Smart Classrooms</p>
     </div>
     <div class="item">
      <div class="f_img bg">
       <img src="<?php echo e(asset('website/images/facility/athletics.png')); ?>" alt="Athletics">
      </div>
      <p>Athletics</p>
     </div>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Our Facility Section End Here -->

<div class="home_our_courses equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <h3 class="main_heading text-center">Our <span>Courses</span></h3>
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Provident illo ipsam fugit expedita.</p>
   </div>
  </div>
  <div class="row">
   <div class="col-lg-2 col-md-3 col-sm-4 col-6">
    <div class="h_course_inner">
     <div class="h_cour_img">
      <div class="hc_img"> 
       <img src="<?php echo e(asset('website/images/courses/nda_foundation.png')); ?>" alt="NDA Foundation">
      </div>
     </div>
     <h4>NDA Foundation</h4>
     <p>(For 8TH & 10TH Pass Students)</p>
    </div>
   </div>
   <div class="col-lg-2 col-md-3 col-sm-4 col-6">
    <div class="h_course_inner">
     <div class="h_cour_img yellow">
      <div class="hc_img"> 
       <img src="<?php echo e(asset('website/images/courses/nda.png')); ?>" alt="NDA">
      </div>
     </div>
     <h4>NDA</h4>
     <p>National Defence Academy</p>
    </div>
   </div>
   <div class="col-lg-2 col-md-3 col-sm-4 col-6">
    <div class="h_course_inner">
     <div class="h_cour_img">
      <div class="hc_img"> 
       <img src="<?php echo e(asset('website/images/courses/ssb.png')); ?>" alt="SSB">
      </div>
     </div>
     <h4>SSB</h4>
     <p>National Defence Academy</p>
    </div>
   </div>
   <div class="col-lg-2 col-md-3 col-sm-4 col-6">
    <div class="h_course_inner">
     <div class="h_cour_img yellow">
      <div class="hc_img"> 
       <img src="<?php echo e(asset('website/images/courses/cds.png')); ?>" alt="CDS">
      </div>
     </div>
     <h4>CDS</h4>
     <p>Combined Defence Services</p>
    </div>
   </div>
   <div class="col-lg-2 col-md-3 col-sm-4 col-6">
    <div class="h_course_inner">
     <div class="h_cour_img">
      <div class="hc_img"> 
       <img src="<?php echo e(asset('website/images/courses/afcat.png')); ?>" alt="AFCAT">
      </div>
     </div>
     <h4>AFCAT</h4>
     <p>Air Force Common Admission Test</p>
    </div>
   </div>
   <div class="col-lg-2 col-md-3 col-sm-4 col-6">
    <div class="h_course_inner">
     <div class="h_cour_img yellow">
      <div class="hc_img"> 
       <img src="<?php echo e(asset('website/images/courses/neet_mns.png')); ?>" alt="NEET + MNS">
      </div>
     </div>
     <h4>NEET + MNS</h4>
     <p>NEET + Military Nursing Services</p>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Our Courses Section End Here -->

<div class="home_module_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-3 col-sm-3 col-6">
    <div class="h_mod_inner mb-4">
     <i class="fas fa-users"></i>
     <div class="count_inner">
     <span class="number">1800</span><i>+</i>
     </div>
     <p>Students</p>
    </div>
   </div>
   <div class="col-md-3 col-sm-3 col-6">
    <div class="h_mod_inner mb-4">
     <i class="fa-solid fa-book"></i>
     <div class="count_inner">
     <span class="number">70</span>
     </div>
     <p>Courses</p>
    </div>
   </div>
   <div class="col-md-3 col-sm-3 col-6">
    <div class="h_mod_inner mb-0">
    <i class="fa-solid fa-user-group"></i>
     <div class="count_inner">
     <span class="number">700</span><i>+</i>
     </div>
     <p>Certified Teachers</p>
    </div>
   </div>
   <div class="col-md-3 col-sm-3 col-6">
    <div class="h_mod_inner mb-0">
     <i class="fa-solid fa-award"></i>
     <div class="count_inner">
     <span class="number">1200</span><i>+</i>
     </div>
     <p>Award Winning</p>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Home Module Section End Here -->

<div class="home_contact_section">
 <div class="container">
  <div class="row">
   <div class="col-lg-7 col-md-8 col-sm-12 col-12">
    <div class="h_cont_form">
     <h3>Get A Free <span>Online Courses</span></h3>
     <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Provident illo ipsam fugit expedita.</p>
     <div class="hm_con_form">
     <?php if(session('message')): ?>
  <div class="alert alert-success" role="alert">
   <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>
      <form method="POST" action="<?php echo e(route('admin.onlile')); ?>">
      <?php echo csrf_field(); ?>
       <div class="row">
        <div class="col-md-6 col-sm-6 col-12">
         <div class="form-group mb-3">
          <input type="text" class="form-control" name="name" placeholder="Enter Name*">
         </div>
        </div>
        <div class="col-md-6 col-sm-6 col-12">
         <div class="form-group mb-3">
          <input type="mail" class="form-control" name="email" placeholder="Enter Email*">
         </div>
        </div>
        <div class="col-md-6 col-sm-6 col-12">
         <div class="form-group mb-3">
          <select class="form-control" placeholder="--Select Courses --" name="course">
           <option value="--Select Courses --">--Select Courses --</option>
           <option value="NDA Foundation">NDA Foundation</option>
           <option value="NDA">NDA</option>
           <option value="SSB Interview">SSB Interview</option>
           <option value="CDS">CDS</option>
           <option value="AFCAT">AFCAT</option>
           <option value="NEET+MNS">NEET+MNS</option>
          </select>
         </div>
        </div>
        <div class="col-md-6 col-sm-6 col-12">
         <div class="form-group mb-3">
          <input type="text" class="form-control" name="number" placeholder="Enter Ph. Number*" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" pattern="[0-9]{10,12}" minlength="10" maxlength="10" required="">
         </div>
        </div>
        <div class="col-md-6">
         <div class="form-group mt-4">
          <button>Apply Now</button>
         </div>
        </div>
       </div>
      </form>
     </div>
    </div>
   </div>
   <div class="col-lg-5 col-md-4 col-sm-12 col-12">
    <div class="h_cont_img">
     <img src="<?php echo e(asset('website/images/h_cont.png')); ?>" alt="Online Courses">
    </div>
   </div>
  </div>
 </div> 
</div>

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
<script>
$('.h_facility_list').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    autoplay:true,
    responsive:{
        0:{
            items:2
        },
        400:{
            items:3
        },
        576:{
            items:4
        },
        767:{
            items:5
        },
        991:{
            items:6
        },
        1200:{
            items:8
        }
    }
})
</script>
<script>
  $(".number").counterUp({time:5000});
</script>
<script>
 <?php if(Session::has('message')): ?>
 var type = "<?php echo e(Session::get('alert-type','info')); ?>"
 switch(type){
    case 'info':
    toastr.info(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'success':
    toastr.success(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'warning':
    toastr.warning(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'error':
    toastr.error(" <?php echo e(Session::get('message')); ?> ");
    break; 
 }
 <?php endif; ?> 
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/index.blade.php ENDPATH**/ ?>