<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>Contact Us | Shield Defence College</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<META NAME="GOOGLEBOT" content="NOINDEX, NOFOLLOW" />
<meta name="yahooSeeker" content="noindex, nofollow" />
<meta name="msnbot" content="noindex, nofollow" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section contact_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>Contact Us</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Contact Us</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="cont_address_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-lg-8 col-md-10 col-sm-12 offset-lg-2">
    <div class="cont_info">
     <h5>CONTACT US</h5>
     <h2>We’re Here to Help You</h2>
     <p>Got a project in mind? We’d love to hear about it. Take five minutes to fill out our project form so that we can get to know you and understand your project.</p>
    </div>
   </div>
  </div>
  <div class="row">
   <div class="col-md-4 col-sm-4 col-12">
    <div class="cont_feat">
     <div class="cont_feat_inner">
      <div class="icon_sec">
       <i class="fas fa-location"></i>
      </div>
      <h4>Visit Us Daily:</h4>
      <p>Gaura, Mohanlalganj, Raebareli Road, Lucknow. 226301</p>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-sm-4 col-12">
    <div class="cont_feat">
     <div class="cont_feat_inner">
      <div class="icon_sec">
       <i class="fas fa-phone"></i>
      </div>
      <h4>Call Us 24/7:</h4>
      <p><a href="tel:09140272051">09140272051</a>,</p>
      <p> <a href="tel:08881444811">08881444811</a></p>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-sm-4 col-12">
    <div class="cont_feat">
     <div class="cont_feat_inner">
      <div class="icon_sec">
       <i class="fas fa-envelope"></i>
      </div>
      <h4>Mail Us 24/7:</h4>
      <p><a href="mailto:integrio@mail.com">integrio@mail.com</a></p>
     </div>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Contact Address Section End Here -->

<div class="cont_form_section">
 <div class="container">
  <div class="row">
   <div class="col-lg-7 col-md-6 col-sm-12 col-12">
    <div class="cont_form">
     <h5>GET IN TOUCH</h5>
     <!-- <h2>Send Us a Message</h2>
     <p>Have some suggestions or just want to say hi? Contact us:</p> -->
     <span></span>
     <form method="POST" action="<?php echo e(route('admin.savecontct')); ?>">
      <?php echo csrf_field(); ?>
      <div class="row">
       <div class="col-lg-6 col-md-12 col-sm-6 col-12">
        <input type="text" name="user" class="form-control" placeholder="Enter Name*" required="">
       </div>
       <div class="col-lg-6 col-md-12 col-sm-6 col-12">
        <input type="email" name="email"class="form-control" placeholder="Enter E-mail*" required="">
       </div>
       <div class="col-lg-6 col-md-12 col-sm-6 col-12">
        <input type="number"name="phone" class="form-control" placeholder="Enter Ph. No.*" required="">
       </div>
       <div class="col-lg-6 col-md-12 col-sm-6 col-12">
        <input type="text" name="subject"class="form-control" placeholder="Enter Subject*" required="">
       </div>
       <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <textarea name="query" class="form-control" rows="4" required=""></textarea>
       </div>
       <div class="col-md-12">
        <button type="submit" name="submit" class="form-control last_inner">Submit</button>
       </div>
      </div>
     </form>
    </div>
   </div>
   <div class="col-lg-5 col-md-6 col-sm-12 col-12">
    <div class="cont_map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m21!1m12!1m3!1d14008.493983013297!2d77.3668853!3d28.6260606!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m6!3e6!4m3!3m2!1d28.6223124!2d77.3701038!4m0!5e0!3m2!1sen!2sin!4v1681877230348!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
   </div>
  </div>
 </div>
</div>

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/contact-us.blade.php ENDPATH**/ ?>