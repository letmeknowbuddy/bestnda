<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>NDA Course | Best Coaching for NDA Preparation</title>
<meta name="keyword" content="NDA Course | Best Coaching for NDA Preparation" >
<meta name="description" content="Shield Defence Collage Provides best NDA Course in Lucknow. Enroll now and start your journey towards a successful career in the armed forces."/>
<link rel="canonical" href="https://shielddefencecollege.com/nda-coaching-in-lucknow/" />
<meta name="ROBOTS" content="index, follow" />
<META NAME="GOOGLEBOT" content="index, follow" />
<meta name="yahooSeeker" content="index, follow" />
<meta name="msnbot" content="index, follow" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="NDA Course | Best Coaching for NDA Preparation" />
<meta property="og:description" content="Shield Defence Collage Provides best NDA Course in Lucknow. Enroll now and start your journey towards a successful career in the armed forces." />
<meta property="og:url" content="https://shielddefencecollege.com/nda-coaching-in-lucknow/" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-04-17T13:34:15+05:30" />
<meta property="og:image" content="https://shielddefencecollege.com/wp-content/uploads/ndabn001.jpg" />
<meta property="og:image:secure_url" content="https://shielddefencecollege.com/wp-content/uploads/ndabn001.jpg" />
<meta property="og:image:width" content="1600" />
<meta property="og:image:height" content="505" />
<meta property="og:image:alt" content="nda coaching in lucknow" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-18T13:50:40+05:30" />
<meta property="article:modified_time" content="2023-04-17T13:34:15+05:30" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="NDA Course | Best Coaching for NDA Preparation" />
<meta name="twitter:description" content="Shield Defence Collage Provides best NDA Course in Lucknow. Enroll now and start your journey towards a successful career in the armed forces." />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/ndabn001.jpg" />
<meta name="twitter:label1" content="Time to read" />
<meta name="twitter:data1" content="12 minutes" />
<!-- SEO Rank End Here -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

 <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section nda_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>NDA Course</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>NDA Course</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="courses_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-lg-9 col-md-9 col-sm-12 col-12">
    <div class="courses_target" id="courses_feature">
     <ul>
      <li><a href="#step1">Information</a></li>
      <li><a href="#step2">Course</a></li>
      <li><a href="#step3">Eligibility</a></li>
      <li><a href="#step4">Syllabus</a></li>
      <li><a href="#step5">Paper</a></li>
     </ul>
    </div>
    <div class="courses_inner" id="step1">
     <span>(NDA Course)</span>
     <h2>National Defence Academy</h2>
     <p>Shield Defence College is best NDA coaching in Lucknow. Success is the product of struggles. You must do what others don’t to achieve what others won’t. And during this fight to achieve your dream of becoming the protector of our great nation we the Shield Defence College, the best coaching in Lucknow  for NDA becomes a precursor for you to escort you through all of your fair cows.</p>
     <p>We thank lady luck for smiling brightly upon us for she has procured the best of the best instructors that the world has to offer, who through their collective hardwork and dedication towards students have made Shield Defence College the best in NDA and CDS coaching in lucknow. We are best defence coaching in Lucknow and best coaching for NDA and CDS Exams.</p>
     <p>The prestigious National Defence College is Asia’s first joint service College which through rigorous training prepares the band of fierce warriors of land, air and sea who defends the glory and integrity of our nation.</p>
    </div>
    <div class="courses_inner" id="step2">
     <h2>Course For NDA</h2>
     <p>NDA course is a comprehensive and intensive training program that provides students with the knowledge and skills required to succeed in the Indian Armed Forces. Shield defence college’s curriculum covers all aspects of the NDA syllabus, including mathematics, general ability test, English, and physical training, our program is designed to prepare students for the challenges and demands of a career in the Armed Forces.It provides them with a good start to excel in the exam of Indian Armed Forces.</p>
     <h3>Why You should Join NDA Course of Shield Defence College</h3>
     <p>Shield defence college provides a pool of experienced faculty and trainers who are committed to providing a supportive and stimulating learning environment that encourages personal growth and development. Our students benefit from personalized attention and guidance, as well as access to the latest training techniques and technology. Our subject experts make the best plans for the NDA program in Lucknow. </p>
     <span>These are the key points that makes Shield Defence college a best destination for NDA</span>
     <h3>Plan Based learning approach</h3>
     <p><strong>Shield Defence college in Lucknow</strong> provides training through an assignment plan that ensures a methodical and realistic approach to NDA test medication. scholars can track their batch progress of syllabus through published assignment plans on notice board. Under the tool of defence experts, doubt clearing sessions after regular classes are handed. We follow the under- mentioned approach for written test medication for NDA & NA examination.</p>
     <h3>Mathematics( Paper 1)</h3>
     <p>As per the syllabus of NDA & NA examination methodical and realistic approach considered where exercises from colorful books are pertained as designed and published by the experts of Shield Defence college and purely distributed into high, advanced, loftiest situations. Since the NDA written test corresponds to one separate paper of Mathematics, we also record distrustfulness clearing sessions for conceptualization and short tricks to have familiarization with learnt conception.</p>
     <h4>Recognized Faculties is our Strength</h4>
     <p>Team Shield has an Elite panel expert that offers strategic approach, short- trick approach, applicable approach and to- the- point approach. Team Shield for written test medication corresponds to a platoon of complete experts with enduring tutoring experience in their separate NDA subjects. Under the tool of defence experts Shield defence academy strength raises high for its selection. It has a  recognized Faculties selection criterion and has all the necessary phases in the reclamation process.</p>
     <h4>NDA Mock test to know their being status</h4>
     <p>Shield defence College who’s known as the Top NDA Coaching Institute in Lucknow, India conducted Weekly mock tests every Saturday in offline mode through our dynamic paper introductory system to make them ready as per the anticipated NDA test pattern. For NDA we’ve an online APP for Online NDA Coaching that gives live videotape, daily test, notes, mistrustfulness session, freee-books. We also give short trick- grounded results to former time examinations in the form of pamphlets.</p>
     <h4>Join NDA guiding for Free Study Material</h4>
     <p>The most applicable and individual searched study material assembled and gathered under the R&D platoon of experts. We’re the stylish NDA guiding in Lucknow, India provides Free study material to scholars, allocated during the sessions avoiding least effective and disorganized request material fluently available at their doorsteps.</p>
     <h4>Exposure to former NDA test Trends</h4>
     <p>Shield defence academy is top NDA guiding in Lucknow, making scholars exercise questions from former time papers with short trick approach. There are topic wise wastes too that make campaigners go through all questions at single sight. Regular sessions for MCQ’s practice in addition to sample paper practice exposure helps scholars to gather numerous confidence and speed for the test at the same time.</p>
     <h4>Retention tricks to stay streamlined with covered motifs</h4>
     <p>To exceed retention in academics we also conduct colorful games,co-curricular conditioning to develop their personality profile as per the parameters of NDA pimp. Memory linking tricks make them comfortable with tough generalities.</p>
    </div>
    <div class="courses_inner" id="step3">
     <h2>Eligibility Criteria</h2>
     <p><span>Sex- </span> Males only</p>
     <p><span>Age Limit for Singles: </span> 16.5 to 19.5 years</p>
     <p><span>Army Education Requirements: </span> 10+2 Passed or Appearing (in any stream)</p>
     <p>For the Air Force, Navy, and Naval Academy, the minimum educational need is 10+2 passing or appearing (With Physics & Mathematics)</p>
     <h3>NDA 2023 Written Exam SYLLABUS</h3>
     <p>National Defence Academy is a premier joint training institution and center of excellence for grooming junior leaders for the Indian armed forces and armed forces of Friendly Foreign Countries. The NDA syllabus underwent modifications and amendments from time to time incorporating current trends and requirements. The NDA syllabus encompasses science, technology, arts and military subjects, candidates appearing for NDA written exam required to analyze subject-wise topics. The objective is to sharpen their analytical abilities and make them capable of taking well informed decisions.</p>
     <h3>NDA 2023 Exam Subjects:</h3>
     <p><span>Paper 1:</span> Mathematics</p>
     <p><span>Paper 2:</span> GAT</p>
     <p><span>Part A:</span> English</p>
     <p><span>Part B:</span> Physics, Chemistry, General Science, Freedom Movements, Current Event</p>
     <h3>NDA Recruitment Drive</h3>
     <p><span>Exam Name:</span> National Defence Academy</p>
     <p><span>Conducting Body:</span> Union Public Service Commission</p>
     <p><span>Official Website:</span> <a href="#!">upsc.gov.in</a></p>
     <p><span>Exam Type:</span> National Level</p>
     <p><span>Mode of Application:</span> Online</p>
     <p><span>Exam Mode:</span> Offline</p>
     <p><span>Selection Process:</span></p>
     <p class="extra_dtl">Phase I- Written Test (Objective Type) <br>
      Phase II- SSB Interview <br>
      Phase III- Medical Test <br>
      Phase IV- Merit List</p>
     <p><span>Tentative Vacancies Per Course:</span></p>
     <p class="extra_dtl">300 (twice a year) or as notified from time to time: Army-195, AF-66, Navy-39 <br>
      NDA(I & II) Exam Notification (in Employment News/ leading daily news Paper/           UPSC website): Dec/Jan and May/June <br>
      NDA(I & II) Exam Conducted: April and September <br>
      Likely SSB Date: Sep to Oct and Jan to Apr <br>
      Commencement of Training: Jan and Jul <br>
      Training Academy: NDA, Khadakwasla, Pune</p>
     <p><span>Duration of Training:</span></p>
     <p class="extra_dtl">3 Yrs at NDA and 1 Yrs at IMA(For Army cadets)/ <br>
      3 Yrs at NDA and 1 Yrs at Naval Academy( for Naval cadets)/ <br>
      3 Yrs at NDA and 1 & ½ Yrs at AFA Hyderabad (For AF cadets)</p>
    </div>
    <div class="courses_inner" id="step4">
     <h2>Syllabus</h2>
     <p>The NDA syllabus aims to develop the personality of cadets as “Soldier-Scholars” who can become confident leaders contributing to national security and the overall development of the nation.</p>
     <h3>NDA Syllabus for Paper 1: Mathematics includes:</h3>
     <ul class="dtl_list">
      <li><span>Algebra: </span>Concept of set, operations on sets, Venn diagrams, De Morgan laws, Cartesian product, relation, equivalence relation, representation of real numbers on a line, complex numbers, binary system of numbers, conversion of a number in the decimal system to binary system and vice versa.</li>
      <li><span>Arithmetic, geometric </span>and harmonic progressions, quadratic equations with real coefficients, solution of linear inequalities of two variables by graphs, permutation and combination, binomial theorem and its applications, logarithms and their applications.</li>
      <li><span>Matrices and determinants: </span>Types of matrices, operations on matrices, determinant of a matrix, basic properties of determinants, adjoint and inverse of a square matrix, applications- Solution of a system of linear equations in two or three unknowns by Cramer’s rule and by Matrix Method.</li>
      <li><span>Trigonometry: </span>Angles and their measures in degrees and in radians, trigonometrical ratios, trigonometric identities, sum and difference formulae, multiple and sub-multiple angles, inverse trigonometric functions, applications-Height and distance, properties of triangles.</li>
      <li><span>Analytical geometry of two and three dimensions: </span>Rectangular Cartesian Coordinate system, distance formula, equation of a line in various forms, angle between two lines, distance of a point from a line, equation of a circle in standard and in general form, standard forms of parabola, ellipse and hyperbola, eccentricity and axis of a conic, point in a three-dimensional space, distance between two points, direction cosines and direction ratios, equation of two points, direction cosines and direction ratios, equation of a plane and a line in various forms, angle between two lines and angle between two planes, equation of a sphere.</li>
      <li><span>Differential calculus: </span>Concept of a real-valued function–domain, range, and graph of a function, composite functions, one-to-one, onto and inverse functions, notion of limit, standard limits, continuity of functions, algebraic operations on continuous functions, derivative of a function at a point, geometrical and physical interpretation of a derivative, applications, derivatives of sum, product and quotient of functions, derivative of a function with respect to another function, derivative of a composite function, second-order derivatives, increasing and decreasing functions, application of derivatives in problems of maxima and minima.</li>
      <li><span>Integral Calculus and Differential Equations </span> <br>
       <p>The concept of integration as the inverse of differentiation, techniques of integration such as substitution and integration by parts, standard integrals involving algebraic expressions, trigonometric, exponential, and hyperbolic functions, evaluation of definite integrals and determination of areas of plane regions bounded by curves, and applications of integration.</p>
       <p>Definition of order and degree of a differential equation, formation of a differential equation with examples, general and particular solutions of differential equations, solution of first-order and first-degree differential equations of various types with examples, and application of differential equations in problems of growth and decay.</p>
      </li>
      <li><span>Vector Algebra </span>
       <p>Vectors in two and three dimensions, magnitude and direction of a vector, unit and null vectors, addition and scalar multiplication of vectors, and scalar product or dot product of two vectors.</p>
      </li>
      <li><span>Analytical geometry of two and three dimensions: </span> Rectangular Cartesian Coordinate system, distance formula, equation of a line in various forms, angle between two lines, distance of a point from a line, equation of a circle in standard and in general form, standard forms of parabola, ellipse and hyperbola, eccentricity and axis of a conic, point in a three-dimensional space, distance between two points, direction cosines and direction ratios, equation of two points, direction cosines and direction ratios, equation of a plane and a line in various forms, angle between two lines and angle between two planes, equation of a sphere.</li>
      <li><span>Differential calculus: </span> Concept of a real-valued function–domain, range, and graph of a function, composite functions, one-to-one, onto and inverse functions, notion of limit, standard limits, continuity of functions, algebraic operations on continuous functions, derivative of a function at a point, geometrical and physical interpretation of a derivative, applications, derivatives of sum, product and quotient of functions, derivative of a function with respect to another function, derivative of a composite function, second-order derivatives, increasing and decreasing functions, application of derivatives in problems of maxima and minima.</li>
      <li><span>Statistics and Probability</span>
       <p><strong>Statistics :</strong> Classification of data, Frequency distribution, cumulative frequency distribution—examples. Graphical representation— Histogram, Pie Chart, frequency polygon— examples. Measures of Central tendency—Mean, median and mode. Variance and standard deviation— determination and comparison. Correlation and regression.</p>
       <p><strong>Probability :</strong> Random experiment, outcomes and associated sample space, events, mutually exclusive and exhaustive events, impossible and certain events. Union and Intersection of events. Complementary, elementary and composite events. Definition of probability—classical and statistical— examples. Elementary theorems on probability—simple problems. Conditional probability, Bayes’ theorem—simple problems. Random variable as function on a sample space. Binomial distribution, examples of random experiments giving rise to Binominal distribution.</p>
      </li>
     </ul>
    </div>
    <div class="courses_inner" id="step5">
     <h2>NDA Syllabus Paper 2 – GAT</h2>
     <span>(Part A: English)</span>
     <p>This section assesses the candidate’s English proficiency in grammar and usage, vocabulary, comprehension, and cohesion in extended texts.</p>
     <p><span>Part B: Section A – Physics</span></p>
     <p>This section covers topics related to Physical Properties and States of Matter, Mass, Weight, Volume, Density and Specific Gravity, Principle of Archimedes, Pressure Barometer, Motion of objects, Velocity and Acceleration, Newton’s Laws of Motion, Force and Momentum, Parallelogram of Forces, Stability and Equilibrium of bodies, Gravitation, elementary ideas of work, Power and Energy, Effects of Heat, Measurement of Temperature and Heat, change of State and Latent Heat, Modes of transference of Heat, Sound waves and their properties, Simple musical instruments, Rectilinear propagation of Light, Reflection and refraction, Spherical mirrors and Lenses, Human Eye, Natural and Artificial Magnets, Properties of a Magnet, Earth as a Magnet, Static and Current Electricity, conductors and Non-conductors, Ohm’s Law, Simple Electrical Circuits, Heating, Lighting and Magnetic effects of Current, Measurement of Electrical Power, Primary and Secondary Cells, Use of X-Rays, General Principles in the working of Simple Pendulum, Simple Pulleys, Siphon, Levers, Balloon, Pumps, Hydrometer, Pressure Cooker, Thermos Flask, Gramophone, Telegraphs, Telephone, Periscope, Telescope, Microscope, Mariner’s Compass, Lightening Conductors, Safety Fuses.</p>
     <p><span>Part B: Section B – Chemistry</span></p>
     <p>This section covers topics related to Physical and Chemical changes, Elements, Mixtures and Compounds, Symbols, Formulae and simple Chemical Equations, Law of Chemical Combination (excluding problems), Properties of Air and Water, Preparation and Properties of Hydrogen, Oxygen, Nitrogen and Carbon dioxide, Oxidation and Reduction, Acids, bases and salts, Carbon— different forms, Fertilizers—Natural and Artificial, Material used in the preparation of substances like Soap, Glass, Ink, Paper, Cement, Paints, Safety Matches and Gun-Powder, Elementary ideas about the structure of Atom, Atomic Equivalent and Molecular Weights, Valency.</p>
     <p><span>Part B: Section C – General Science</span></p>
     <p>This section covers topics related to Difference between the living and non-living, Basis of Life—Cells, Protoplasm and Tissues, Growth and Reproduction in Plants and Animals, Elementary knowledge of Human Body and its important organs, Common Epidemics, their causes and prevention, Food—Source of Energy for man, Constituents of food, Balanced Diet, The Solar System—Meteors and Comets, Eclipses, Achievements of Eminent Scientists.</p>
     <p><span>Part B: Section D – Freedom movement etc.</span></p>
     <p>This section covers topics related to a broad survey of Indian History, with emphasis on Culture and Civilization, Freedom Movement in India, Elementary study of Indian Constitution and Administration, Elementary knowledge of Five Year Plans of India, Panchayati Raj, Co-operatives and Community Development, Bhoodan, Sarvodaya, National Integration and Welfare State, Basic Teachings of Mahatma Gandhi, Forces shaping the modern world; Renaissance, Exploration and Discovery; War of American Independence, French Revolution, Industrial Revolution and Russian Revolution, Impact of Science and Technology on Society, Concept of one World, United Nations, Panchsheel, Democracy, Socialism and Communism, Role of India in the present world.</p>
    </div>
   </div>

   <div class="col-lg-3 col-md-3 col-sm-12 col-12">
  
    <?php echo $__env->make('include.side-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   </div>
  </div>
 </div>
</div>



<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->



<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>

<!-- <script>
window.onscroll = function() {myFunction()};
var courses_target = document.getElementById("courses_feature");
var sticky = courses_target.offsetTop;
function myFunction() {
  if (window.pageYOffset > sticky) {
    courses_target.classList.add("sticky");
  } else {
    courses_target.classList.remove("sticky");
  }
}
</script> -->
</body>
</html><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/nda-coaching-in-lucknow.blade.php ENDPATH**/ ?>