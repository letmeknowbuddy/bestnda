<?php 
$resentblog = DB::table('add_blog')->where('status', 0)->orderBy('id', 'desc')->get();
$webmaster_update  = DB::Table('webmaster_update')->where('id', 1)->first();
$analytics_update  = DB::Table('analytics_update')->where('id', 1)->first();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.webp">
<title><?php echo html_entity_decode(@$blogs->blog_title, ENT_QUOTES | ENT_HTML5, 'UTF-8') ?></title>
<meta content="Best NDA Coaching in Lucknow | Best Defence Coaching - Shield Defence College" name="keywords">
<meta content="Shield Defence College is a Best NDA and CDS Coaching in Lucknow offers Best Defence Coaching for NDA, CDS, AFCAT, MNS Exam." name="description">
<link rel="canonical" href="<?php echo e(URL::current()); ?>">
<link rel="amphtml" href="<?php echo e(URL::current()); ?>">
<link rel="alternate" href="" hreflang="en-us">
<meta name="google-site-verification" content="<?php echo $webmaster_update->google ?>" />
<meta name="yandex-verification" content="<?php echo $webmaster_update->yandex ?>" />
<!-- <meta name="msvalidate.01" content="<?php echo $webmaster_update->pintrest ?>" /> -->
<meta name="ROBOTS" content="INDEX, FOLLOW">
<META NAME="GOOGLEBOT" content="INDEX, FOLLOW">
<meta name="yahooSeeker" content="index, follow">
<meta name="msnbot" content="index, follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Shield Defence College">
<meta property="og:title" content="Best NDA Coaching in Lucknow | Best Defence Coaching - Shield Defence College" />
<meta property="og:description" content="Shield Defence College is a Best NDA and CDS Coaching in Lucknow offers Best Defence Coaching for NDA, CDS, AFCAT, MNS Exam." />
<meta property="og:url" content="https://shielddefencecollege.com/" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:image" content="/" />
<meta property="og:image:secure_url" content="/" />
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="600" />
<meta property="og:image:alt" content="NDA Coaching in Lucknow" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-04T00:28:23+05:30" />
<meta property="article:modified_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:ttl" content="345600">
<meta property="fb:profile_id" content="/">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="/">
<meta name="twitter:creator" content="/">
<meta name="twitter:title" content="Best NDA Coaching in Lucknow | Best Defence Coaching - Shield Defence College" />
<meta name="twitter:description" content="Shield Defence College is a Best NDA and CDS Coaching in Lucknow offers Best Defence Coaching for NDA, CDS, AFCAT, MNS Exam." />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/Shield-Defence-Logo-3.jpg" />
<meta name="twitter:label1" content="Written by" />
<meta name="twitter:data1" content="Sdacollege" />
<meta name="twitter:label2" content="Time to read" />
<meta name="twitter:data2" content="1 minute" />
<meta property="og:updated_time" content="2021-01-06T13:49:21">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
<?php echo $analytics_update->header; ?>

</head>
<body>
<?php echo $analytics_update->body; ?>


<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="blog_list_section equal_space top_border">
 <div class="container-fluid">
  <div class="row">
   <div class="col-md-9 col-sm-12 col-12">
    <div class="blog_inner">
     <div class="blog_inn_banner">
      <img src="<?php echo e(URL::asset('blog_image/thumbimg/' .$blogs->thumbimg)); ?>" alt="/" class="img-fluid">
     </div>
     <div class="blog_inn_dtl">
      <ul class="user_dtl">
       <li><i class="fa-solid fa-user"></i> <a href="#!"><?php echo e($blogs->u_name); ?></a></li>
        <li><i class="fas fa-clock"></i> <?php echo e(date("d M Y", strtotime($blogs->create_at))); ?></li>
       <li><i class="fa-solid fa-th"></i> <a href="#!"><?php echo e($blogs->category); ?></a></li>
       <li><i class="fa-solid fa-eye"></i> <a href="#!">5</a></li>
      </ul>
      <h2><?php echo e($blogs->blog_title); ?></h2>
      <p><p><?php echo html_entity_decode($blogs->blog); ?></p></p>
     </div>
    </div>
   </div>

   <div class="col-md-3 col-sm-12 col-12">
    <div class="blog_side">
     <h3>Search</h3>
     <form>
      <input type="text" placeholder="Find Keywords" required="" fdprocessedid="j9by29">
      <button type="submit" class="searchbutton"><i class="fa-solid fa-search"></i></button>
     </form>
    </div>
    <div class="blog_side">
     <h4>Trending</h4>
     <ul>
       <li><a href="#!">NDA Foundation</a><span>(25)</span></li>
       <li><a href="#!">NDA</a><span>(25)</span></li>
       <li><a href="#!">SSB Interview</a><span>(25)</span></li>
       <li><a href="#!">CDS</a><span>(25)</span></li>
       <li><a href="#!">AFCAT</a><span>(25)</span></li>
       <li><a href="#!">NEET + MNS</a><span>(25)</span></li>
       <li><a href="#!">MNS</a><span>(25)</span></li>
     </ul>
    </div>
    <div class="blog_side">
     <h4>Latest Blog</h4>
     <ul>
       <?php 
        foreach ($resentblog as $newBlog) 
        {
          ?>
        <li><a href="<?php echo e(route('blog-details',$blogs->blog_slug)); ?>"><?php echo e($newBlog->blog_title); ?></a></li>

          <?php
        }


       ?>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Blog Details Section End Here -->


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/blog-details.blade.php ENDPATH**/ ?>