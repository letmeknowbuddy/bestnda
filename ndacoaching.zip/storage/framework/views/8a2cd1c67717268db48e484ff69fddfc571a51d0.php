<footer id="footer">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <p class="text-center"> Copyright &copy; 2023 <a href="index.php">Shield Defence College</a> | All Rights Reserved.</p>
      </div>
    </div>
  </div>
</footer>

<script type="text/javascript" src="js/custom.js"></script>
<?php /**PATH C:\xampp\htdocs\mohd\bestndacoachinginlucknow_final\resources\views/admin/include/footer.blade.php ENDPATH**/ ?>