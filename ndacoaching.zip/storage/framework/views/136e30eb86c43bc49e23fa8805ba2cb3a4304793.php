<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="shortcut icon" href="images/favicon.webp" alt="LMS">
<title>Dashboard | Shield Defence College</title>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css/stylesheet.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset ('backend/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset ('backend/js/system.js')); ?>"></script>
</head>
<body>
 <?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('admin.include.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content" class="container-fluid">
 <div class="row dashboard-stats">
  <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 primary">
   <div class="tile">
    <a href="contact_list.php">
     <div class="heading">Contacts</div>
     <div class="body"> <i class="fas fa-phone-volume"></i>
      <div class="pull-right"> 3 </div>
     </div>
    </a>
   </div>
  </div>
  <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 primary">
   <div class="tile">
    <a href="enquiry_list.php">
     <div class="heading">Enquery</div>
     <div class="body"> <i class="fas fa-phone-volume"></i>
      <div class="pull-right"> 3 </div>
     </div>
    </a>
   </div>
  </div>
  <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 primary">
   <div class="tile">
    <a href="call_back_list.php">
     <div class="heading">Call Back</div>
     <div class="body"> <i class="fas fa-phone-volume"></i>
      <div class="pull-right"> 3 </div>
     </div>
    </a>
   </div>
  </div>
  <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 primary">
   <div class="tile">
    <a href="online_registration.php">
     <div class="heading">Online Registration</div>
     <div class="body"> <i class="fas fa-phone-volume"></i>
      <div class="pull-right"> 3 </div>
     </div>
    </a>
   </div>
  </div>
  <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 primary">
   <div class="tile">
    <a href="online_fee_pay.php">
     <div class="heading">Online Fee Payment</div>
     <div class="body"> <i class="fas fa-phone-volume"></i>
      <div class="pull-right"> 3 </div>
     </div>
    </a>
   </div>
  </div>
  <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 primary">
   <div class="tile">
    <a href="category.php">
     <div class="heading">Category</div>
     <div class="body"> <i class="fas fa-chart-pie"></i>
      <div class="pull-right"> 3 </div>
     </div>
    </a>
   </div>
  </div> 
  <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 primary">
   <div class="tile">
    <a href="blogs.php">
     <div class="heading">Blogs</div>
     <div class="body"> <i class="fa-solid fa-blog"></i>
      <div class="pull-right"> 3 </div>
     </div>
    </a>
   </div>
  </div>

 </div>
</div>
<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\mohd\bestndacoachinginlucknow_final\resources\views/admin/dashborad.blade.php ENDPATH**/ ?>