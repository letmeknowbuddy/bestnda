<?php
$webmaster_update  = DB::Table('webmaster_update')->where('id', 1)->first();
$analytics_update  = DB::Table('analytics_update')->where('id', 1)->first();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>Our Vision - Shield Defence College</title>
<meta content="Our Vision - Shield Defence College" name="keywords">
<meta content="Shield Defence College is committed to achieve excellence through execution, imparting quality teaching by unparalleled pedagogy, untiring advance to" name="description">
<link rel="canonical" href="<?php echo e(URL::current()); ?>">
<link rel="amphtml" href="<?php echo e(URL::current()); ?>">
<link rel="alternate" href="<?php echo e(URL::current()); ?>" hreflang="en-us">
<meta name="google-site-verification" content="<?php echo $webmaster_update->google ?>" />
<meta name="yandex-verification" content="<?php echo $webmaster_update->yandex ?>" />
<!-- <meta name="msvalidate.01" content="<?php echo $webmaster_update->pintrest ?>" /> -->
<meta name="ROBOTS" content="INDEX, FOLLOW">
<META NAME="GOOGLEBOT" content="INDEX, FOLLOW">
<meta name="yahooSeeker" content="index, follow">
<meta name="msnbot" content="index, follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Shield Defence College">
<meta property="og:title" content="Our Vision - Shield Defence College" />
<meta property="og:description" content="Shield Defence College is committed to achieve excellence through execution, imparting quality teaching by unparalleled pedagogy, untiring advance to" />
<meta property="og:url" content="<?php echo e(URL::current()); ?>" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:image" content="/" />
<meta property="og:image:secure_url" content="/" />
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="600" />
<meta property="og:image:alt" content="Our Vision" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-04T00:28:23+05:30" />
<meta property="article:modified_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:ttl" content="345600">
<meta property="fb:profile_id" content="/">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="/">
<meta name="twitter:creator" content="/">
<meta name="twitter:title" content="Our Vision - Shield Defence College" />
<meta name="twitter:description" content="Shield Defence College is committed to achieve excellence through execution, imparting quality teaching by unparalleled pedagogy, untiring advance to" />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/Shield-Defence-Logo-3.jpg" />
<meta name="twitter:label1" content="Written by" />
<meta name="twitter:data1" content="Sdacollege" />
<meta name="twitter:label2" content="Time to read" />
<meta name="twitter:data2" content="1 minute" />
<meta property="og:updated_time" content="2021-01-06T13:49:21">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
<?php echo $analytics_update->header; ?>

</head>
<body>
<?php echo $analytics_update->body; ?>


<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section vision_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>AIM & Vision</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Our Vision</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="about_normal_content">
 <div class="container">
  <div class="row">
   <div class="col-lg-8 col-md-7 col-sm-12 col-12">
    <div class="nor_cont_inner">
     <h6 class="sub_title">SHIELD DEFENCE COLLEGE</h6>
     <h2>Aim & Vision</h2>
     <p>Shield Defence College is committed to achieve excellence through execution, imparting quality teaching by unparalleled pedagogy, untiring advance to excellence and MAKING A DIFFERENCE. SDC will continue striving at creating the institution a centre of highest calibre of learning, so as to create an overall intellectual atmosphere with each deriving strength from the other to be the best of OFFICERS in Indian Armed Forces.</p>
     <p>We at SDC; reiterate our stand on enhancing the cultivation of virtues through value identification, reinforcement and optimising your chances of success by-</p>
     <ul>
      <li>Using unmatched teaching strategies, discussions, group activity, outdoor activities, value education, adventure sports and excursions.</li>
      <li>by developing qualities of body, mind and character which will enable the young boys and girls of today to become good and useful citizens of tomorrow.</li>
      <li>To prepare those who fail to make the grade for the NDA for responsible positions in various other walks of life.</li>
     </ul>
     <p>As a defence college, your vision could encompass the following elements:</p>
     <h3>Excellence in Education and Training:</h3>
     <p>Shield defence college aims to be recognized as a premier institution that provides exceptional education and training to military and civilian defence professionals. This includes delivering comprehensive, relevant, and rigorous programs that develop critical thinking, leadership, and decision-making skills, and preparing defence professionals for leadership roles in a rapidly changing security landscape.</p>
     <h3>Research and Innovation:</h3>
     <p>The defence Academy strives to be at the forefront of defence research and innovation. This involves conducting original research, generating new knowledge, and exploring emerging technologies and concepts that have the potential to shape the future of defence and national security. Your defence college seeks to foster a culture of innovation and adaptation, and actively contribute to the advancement of defence theories, strategies, and capabilities.</p>
     <h3>Ethical Leadership and Professionalism:</h3>
     <p>Your defence college places a high emphasis on ethical leadership, professionalism, and moral education. Your vision includes developing defence professionals who are not only competent in their technical skills but also possess a strong sense of ethical responsibility, integrity, and professionalism. Your defence college strives to instill values of respect for human rights, adherence to international law, and ethical decision-making in defence operations and policy making.</p>
     <p>The vision of your defence college would be to be a leading institution in defence education, research, and innovation, fostering ethical leadership, global engagement, inclusivity, and lifelong learning, and contributing to the preparedness of defence professionals and the nation’s defence establishment.</p>
    </div>
   </div>
   <div class="col-lg-4 col-md-5 col-sm-12 col-12">
    <div class="abt_norml_cont_img">
     <img src="website/images/our_vision.webp" alt="Aim & Vision | SHIELD DEFENCE COLLEGE">
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Normal Content Section End Here -->

<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->


<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/our-vision.blade.php ENDPATH**/ ?>