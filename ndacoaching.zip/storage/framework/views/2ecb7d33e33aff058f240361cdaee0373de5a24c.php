<div class="side_form">
 <h6>Enquiry Form</h6>
 <form method="POST" action="<?php echo e(route('admin.save')); ?>">
  <?php echo csrf_field(); ?>
  <div class="row">
   <div class="col-lg-12 col-md-12 col-sm-6 col-12">
    <input type="text" name="name" placeholder="Enter Your Name" class="form-control">
   </div>
   <div class="col-lg-12 col-md-12 col-sm-6 col-12">
    <input type="number" name="number" placeholder="Enter Mobile No." class="form-control">
   </div>
   <div class="col-lg-12 col-md-12 col-sm-6 col-12">
   <select class="form-control" placeholder="--Select Courses --" name="course">
     <option value="--Select Courses --">--Select Courses --</option>
     <option value="NDA Foundation">NDA Foundation</option>
     <option value="NDA">NDA</option>
     <option value="SSB Interview">SSB Interview</option>
     <option value="CDS">CDS</option>
     <option value="AFCAT">AFCAT</option>
     <option value="NEET+MNS">NEET+MNS</option>
    </select>
   </div>
   <div class="col-lg-12 col-md-12 col-sm-6 col-12">
    <button type="submit" name="submit" class="form-control mb-0">Submit</button>
   </div>
  </div>
 </form>
</div><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/include/side-form.blade.php ENDPATH**/ ?>