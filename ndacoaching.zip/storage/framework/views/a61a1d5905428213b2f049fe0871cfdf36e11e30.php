<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.webp">
<title>Core Values | Shield Defence College</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<META NAME="GOOGLEBOT" content="NOINDEX, NOFOLLOW" />
<meta name="yahooSeeker" content="noindex, nofollow" />
<meta name="msnbot" content="noindex, nofollow" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section core_value_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>Core Values</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Core Values</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="about_normal_content">
 <div class="container">
  <div class="row">
   <div class="col-lg-8 col-md-7 col-sm-12 col-12">
    <div class="nor_cont_inner">
     <h6 class="sub_title">SHIELD DEFENCE COLLEGE</h6>
     <h2>Core Values</h2>
     <p><span>INTEGRITY-</span> Ability to realise the greater good in our actions and to look at our work and ourselves holistically.</p>
     <ul class="dtl_list">
      <li><span>Ethical Standards-</span> In all we do, we apply and expect the highest personal, professional and ethical standards. We believe in acting with honesty, courage and trust.</li>
      <li><span>Transparency and Fairness-</span> Collectively and individually we act with transparency, consistency and fairness.</li>
     </ul>
     <p><span>LEADERSHIP–</span>We believe in cultivating a culture of genuine sincerity, trust and collaboration at all levels through value-based leadership</p>
     <ul class="dtl_list">
      <li><span>Governance-</span> We embark on a value-based approach across all our actions.</li>
      <li><span>Leadership Development-</span> Fostering value-based leadership among faculty members, students and staff in all their actions.</li>
     </ul>
     <p><span>EXCELLENCE-</span> Pursuit of excellence through innovation, collaboration, and continuous improvement.</p>
     <p><span>DIVERSITY-</span> We respect and encourage diversity among students, faculty members and staff to promote cross-cultural environment</p>
     <ul class="dtl_list">
      <li><span>Equity</span> We embrace everyone with equity and dignity irrespective of their social background.</li>
      <li><span>Cross-cultural Environment</span> University encourages cross-cultural groups and team building inside and outside the classrooms. The students, faculty members and staff work together in a cohesive learning environment to achieve the vision and mission of the University.</li>
     </ul>
    </div>
   </div>
   <div class="col-lg-4 col-md-5 col-sm-12 col-12">
    <div class="abt_norml_cont_img">
     <img src="/website/images/core-values.webp" alt="Aim & Vision | SHIELD DEFENCE COLLEGE">
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Normal Content Section End Here -->


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->


<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/core-values.blade.php ENDPATH**/ ?>