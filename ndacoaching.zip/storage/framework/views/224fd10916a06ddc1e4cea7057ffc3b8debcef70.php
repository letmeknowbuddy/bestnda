<?php
$webmaster_update  = DB::Table('webmaster_update')->where('id', 1)->first();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.webp">
<title>No.1 SSB Coaching in Lucknow | Best SSB Interview Coaching in Lucknow</title>
<meta content="No.1 SSB Coaching in Lucknow | Best SSB Interview Coaching in Lucknow" name="keywords">
<meta content="Shield Defence College is one of the best SSB coaching in Lucknow. We provide SSB interview coaching in Lucknow for NDA, CDS, Airforce & Navy. Call us today!" name="description">
<link rel="canonical" href="<?php echo e(URL::current()); ?>">
<link rel="amphtml" href="<?php echo e(URL::current()); ?>">
<link rel="alternate" href="<?php echo e(URL::current()); ?>" hreflang="en-us">
<meta name="google-site-verification" content="<?php echo $webmaster_update->google ?>" />
<meta name="yandex-verification" content="<?php echo $webmaster_update->yandex ?>" />
<!-- <meta name="msvalidate.01" content="<?php echo $webmaster_update->pintrest ?>" /> -->
<meta name="ROBOTS" content="INDEX, FOLLOW">
<META NAME="GOOGLEBOT" content="INDEX, FOLLOW">
<meta name="yahooSeeker" content="index, follow">
<meta name="msnbot" content="index, follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Shield Defence College">
<meta property="og:title" content="No.1 SSB Coaching in Lucknow | Best SSB Interview Coaching in Lucknow" />
<meta property="og:description" content="Shield Defence College is one of the best SSB coaching in Lucknow. We provide SSB interview coaching in Lucknow for NDA, CDS, Airforce & Navy. Call us today!" />
<meta property="og:url" content="<?php echo e(URL::current()); ?>" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:image" content="/" />
<meta property="og:image:secure_url" content="/" />
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="600" />
<meta property="og:image:alt" content="No.1 SSB Coaching in Lucknow" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-04T00:28:23+05:30" />
<meta property="article:modified_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:ttl" content="345600">
<meta property="fb:profile_id" content="/">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="/">
<meta name="twitter:creator" content="/">
<meta name="twitter:title" content="No.1 SSB Coaching in Lucknow | Best SSB Interview Coaching in Lucknow" />
<meta name="twitter:description" content="Shield Defence College is one of the best SSB coaching in Lucknow. We provide SSB interview coaching in Lucknow for NDA, CDS, Airforce & Navy. Call us today!" />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/Shield-Defence-Logo-3.jpg" />
<meta name="twitter:label1" content="Written by" />
<meta name="twitter:data1" content="Sdacollege" />
<meta name="twitter:label2" content="Time to read" />
<meta name="twitter:data2" content="1 minute" />
<meta property="og:updated_time" content="2021-01-06T13:49:21">
<!-- SEO Rank End Here -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section ssb_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>SSB Interview Preparation</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>SSB Interview Preparation</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="courses_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-lg-9 col-md-9 col-sm-12 col-12">
     <div class="courses_target" id="courses_feature">
      <ul>
       <li><a href="#step1">Information</a></li>
       <li><a href="#step2">About</a></li>
       <li><a href="#step3">Interview</a></li>
      </ul>
     </div>
    <div class="courses_inner" id="step1">
     <span>(SSB COURSE)</span>
     <h2>Services Selection Board</h2>
     <p>Services Selection Board (SSB) is an organization that assesses the candidates for becoming officers into the Indian Armed Forces. Best SSB College in Lucknow, Shield Defence Academy trains you for SSB in an best and systematic manner. The board evaluates the suitability of the candidate for becoming an officer using a standardized protocol of evaluation system which constitutes of personality, intelligence tests, and interviews. Best SSB College In Lucknow, gives you wings to fly high and be a cut above.</p>
     <p>The tests are of both types i.e. written and practical task-based. An SSB comprises the panel of assessors, who are officers in Indian Armed Forces and having their specialization as Psychologist, GTO (Group Task Officer) and Interviewing Officer. In total there are thirteen Service Selection Boards across India, out of which four boards are for Indian Army, four boards are for Indian Air Force and five boards for Indian Navy. SSB is a 5 days evaluation process.</p>
     <p><span>Shield Defence Academy, best SSB College in Lucknow gives you 3 classroom programme:</span></p>
     <ol>
      <li>14 Days (Two weeks).</li>
      <li>21 Days (Three weeks).</li>
      <li>30 Days (One Month).</li>
     </ol>
     <p>Preparing for this insanely tough examination is nothing short of a herculean task. And for this reason we at Shield Defence Academy has taken it upon ourselves to accoutre the aspirants with all the knowledge that they need to crush this examination easily. We are the best College for SSB in Lucknow not only because of our specially designed infrastructure but also due to the unmatched proficient teachers that have come under one roof to share the elixir of knowledge.</p>
    </div>
    <div class="courses_inner" id="step2">
     <h2>SSB (Service Selection Board)</h2>
      <p>The SSB (Service Selection Board) interview is a selection process conducted by the Indian Armed Forces to select candidates for officer-level positions in the Army, Navy, and Air Force. The SSB interview is a five-day process that assesses a candidate’s physical, psychological, and intellectual abilities.</p>
      <p><span>Here are the details for SSB interview training:</span></p>
      <ol>
       <li><span>Physical Fitness: </span> The first thing that candidates need to focus on is their physical fitness. The SSB interview includes several physical tests such as running, push-ups, sit-ups, and obstacle course. It is essential to be in good physical condition to pass these tests. Candidates can join a gym or start a fitness routine to prepare for the physical tests.</li>
       <li><span>Practice Group Discussion: </span> Group Discussion (GD) is an important part of the SSB interview. Candidates need to practice their communication skills and learn how to express their opinions effectively in a group. Joining a coaching institute or practicing with friends can help in developing this skill.</li>
       <li><span>Develop Leadership qualities: </span> The SSB interview is designed to assess the leadership qualities of the candidates. Candidates should focus on developing qualities such as decision-making, problem-solving, and communication skills. They should also have knowledge of current affairs and general knowledge.</li>
       <li><span>Interview preparation: </span> Candidates should also prepare for the personal interview by practicing their communication skills, preparing for commonly asked questions, and researching about the organization they are applying for.</li>
       <li><span>Psychological Tests: </span> The SSB interview includes several psychological tests such as the Thematic Apperception Test (TAT), Word Association Test (WAT), and Situation Reaction Test (SRT). Candidates can practice these tests with the help of coaching institutes or online resources.</li>
       <li><span>Mock Interviews: </span> Mock interviews can be a great way to prepare for the SSB interview. Candidates can seek the help of their friends, family members, or join a coaching institute to practice mock interviews.</li>
      </ol>
      <h3>Perks of joining Shield Defence College for SSB</h3>
      <p>Attending a coaching institute can help you increase your productivity and speed up your NDA medication in constantly fierce competition. Shield Defence Academy, the stylish NDA SSB Coaching in Lucknow, provides scholars with a comprehensive training plan under the supervision and mentorship of educated professionals.</p>
      <p><span>The following are the most significant benefits of joining Shield defence academy:</span></p>
      <ul class="dtl_list">
       <li>Candidates have the facility of mock tests,model test and test series to get a feel for the real exam while retaining accuracy and time management.</li>
       <li>A well- equipped library and state- of- the- art structure with all necessary amenities produce a terrain that promotes a positive and pleasurable literacy experience.</li>
       <li>Content and study accoutrements that have been completely delved and are grounded on the rearmost syllabus and test pattern, as determined by the R&D department.</li>
       <li>Our experienced faculty and trainers have a deep understanding of the1</li>
      </ul>
    </div>
    <div class="courses_inner" id="step3">
     <h2>SSB Interview Selection Procedures</h2>
     <ul>
      <li>The two vital stages of this whole process of coaching for SSB are:</li>
      <li>STAGE-I Testing</li>
      <li>Screening</li>
      <li>STAGE II Testing</li>
      <li>Psychology</li>
      <li>GTO</li>
      <li>Personal Interview.</li>
      <li>Conference.</li>
     </ul>
     <h3>STAGE-I Testing</h3>
     <p><span>1. SCREENING: </span> Screening is the preliminary stage for filtering out the potential candidates from all the candidates who have applied for the SSB. In screening, the selection is done on the basis of following two tests.</p>
     <ul class="dtl_list">
      <li><span>Verbal and Non-Verbal Test</span></li>
      <li><span>Picture Perception and Discussion Test (PPDT)</span></li>
     </ul>
     <p>The next stage . It is on the basis of these three virtues that the candidates participating in the SSB examination are judged and selected as Officer</p>
     <h3>STAGE-II Testing</h3>
     <p><span>2. PSYCHOLOGY (Mansa): </span> After the list of candidates who have cleared the Stage I is out, the second stage begins. This stage is specifically designed to tests the psychology of the students.</p>
     <ul class="dtl_list">
      <li><span>Thematic Appreciation Test (TAT)</span></li>
      <li><span>Word Association Test (WAT)</span></li>
      <li><span>Situation Reaction Test (SRT)</span></li>
      <li><span>Self Description Test (SD)</span></li>
     </ul>
     <p><span>3. GTO (VAACHA): </span> Post Psychological testing round involved in, candidates needs to perform some outdoor tasks. s this stage of selection process is conducted by Group Testing Officer (GTO).</p>
     <p>There are a total of nine tasks on basis of which the candidates are to be selected.</p>
     <ul class="dtl_list">
      <li><span>Group Discussion (GD)</span></li>
      <li><span>GPE or MPE (group/military planning exercise)</span></li>
      <li><span>Progressive group task (PGT)</span></li>
      <li><span>Snake Race/Group Obstacle Race</span></li>
      <li><span>Individual Lecturette (IO)</span></li>
      <li><span>Half Group Task (HGT)</span></li>
      <li><span>Individual Obstacles</span></li>
      <li><span>Command task:</span></li>
      <li><span>Final Group Task (FGT)</span></li>
     </ul>
     <p><span>4. PERSONAL INTERVIEW:</span> After the rigorous selection process consisting of colorful tasks and conditioning, the campaigners move on to a stage of consummate significance.</p>
     <p>The particular Interview( PI) can be entitled as a purposeful discussion between the seeker and the Interviewing officers for about 50 to 60 twinkles. The primary purpose of the whole PI process is to particularly check for Officer like rates( OLQs) in the seeker appearing for the SSB examination.</p>
     <p>At Shield defence academy, we believe in all- round work. We work rigorously towards fulfilling your dream of getting an officer in the Indian Armed Forces. We know we’re stylish at what we do and that’s why we’re one of the stylish SSB guides in lucknow. At our academy, we believe in quality over volume. That is the reason that we offer limited seats in a single batch so that proper emphasis is laid on each and every student.</p>
    </div>
   </div>

   <div class="col-lg-3 col-md-3 col-sm-12 col-12">
   
    <?php echo $__env->make('include.side-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </div>
  </div>
 </div>
</div>


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->


<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>

<!-- <script>
window.onscroll = function() {myFunction()};
var courses_target = document.getElementById("courses_feature");
var sticky = courses_target.offsetTop;
function myFunction() {
  if (window.pageYOffset > sticky) {
    courses_target.classList.add("sticky");
  } else {
    courses_target.classList.remove("sticky");
  }
}
</script> -->
</body>
</html><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/ssb-coaching-in-lucknow.blade.php ENDPATH**/ ?>