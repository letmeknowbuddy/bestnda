<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>No.1 CDS Coaching in Lucknow | Best CDS Coaching Centre in Lucknow</title>
<meta content="No.1 CDS Coaching in Lucknow | Best CDS Coaching Centre in Lucknow" name="keywords">
<meta content="Shield Defence College Provides best CDS Coaching in Lucknow, With experienced instructors, proven teaching methods. We provide top CDS classes for defence aspirants." name="description">
<link rel="canonical" href="/">
<link rel="amphtml" href="/">
<link rel="alternate" href="/" hreflang="en-us">
<meta name="google-site-verification" content="/">
<meta name="yandex-verification" content="/">
<meta name="ROBOTS" content="INDEX, FOLLOW">
<META NAME="GOOGLEBOT" content="INDEX, FOLLOW">
<meta name="yahooSeeker" content="index, follow">
<meta name="msnbot" content="index, follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Shield Defence College">
<meta property="og:title" content="No.1 CDS Coaching in Lucknow | Best CDS Coaching Centre in Lucknow" />
<meta property="og:description" content="Shield Defence College Provides best CDS Coaching in Lucknow, With experienced instructors, proven teaching methods. We provide top CDS classes for defence aspirants." />
<meta property="og:url" content="/" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:image" content="/" />
<meta property="og:image:secure_url" content="/" />
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="600" />
<meta property="og:image:alt" content="No.1 CDS Coaching in Lucknow" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-04T00:28:23+05:30" />
<meta property="article:modified_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:ttl" content="345600">
<meta property="fb:profile_id" content="/">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="/">
<meta name="twitter:creator" content="/">
<meta name="twitter:title" content="No.1 CDS Coaching in Lucknow | Best CDS Coaching Centre in Lucknow" />
<meta name="twitter:description" content="Shield Defence College Provides best CDS Coaching in Lucknow, With experienced instructors, proven teaching methods. We provide top CDS classes for defence aspirants." />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/Shield-Defence-Logo-3.jpg" />
<meta name="twitter:label1" content="Written by" />
<meta name="twitter:data1" content="Sdacollege" />
<meta name="twitter:label2" content="Time to read" />
<meta name="twitter:data2" content="1 minute" />
<meta property="og:updated_time" content="2021-01-06T13:49:21">
<!-- SEO Rank End Here -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section cds_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>CDS Coaching Classes</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>CDS Coaching Classes</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="courses_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-lg-9 col-md-9 col-sm-12 col-12">
    <div class="courses_target" id="courses_feature">
     <ul>
      <li><a href="#step1">Information</a></li>
      <li><a href="#step2">Exam</a></li>
      <li><a href="#step3">Syllabus</a></li>
     </ul>
    </div>
    <div class="courses_inner" id="step1">
     <span>(CDS COURSE)</span>
     <h2>Combined Defence Services</h2>
     <p>Shield Defence College is best CDS College in Lucknow. Combined Defence Services or CDS examination is conducted to recruit candidates in the Indian Armed Forces. Aspirants willing to become a part of Indian Military College, Indian Naval College, Officers Training College, and Indian Air Force College can apply for the CDS exam and chase their dream career.</p>
     <p>Our prestigious institute Shield Defence College is the best CDS College in Lucknow which has produced wonderful result in the past couple of years. It takes an immeasurable amount of hard work and diligence for an aspirant to realize his dream of serving the nation and for this reason we at Shield Defence College create an officer out of a shieldian.</p>
     <p>We boast about us being the best College for CDS Examination. Shield Defence College, best Defence Coaching in Lucknow will provide you the best of the best environment.</p>
    </div>
    <div class="courses_inner" id="step2">
     <h2>CDS EXAM</h2>
     <p>Shield Defence College’s CDS (Combined Defence Services) course is a comprehensive program designed to help students prepare for the CDS exam, which is a gateway to becoming an officer in the Indian Armed Forces. Our program is designed to provide students with a strong foundation in the subjects required for the exam, including mathematics, English, and general knowledge.</p>
     <p>Our experienced faculty and trainers have a deep understanding of the CDS exam and provide personalized attention and guidance to each student. Our program covers all aspects of the exam, including paper 1 (English and general knowledge) and paper 2 (mathematics).</p>
     <p>Joining Shield Defence College’s CDS course is an excellent opportunity for students who are passionate about serving their country and aspire to become officers in the Indian Armed Forces. Our program is designed to provide students with the knowledge, skills, and confidence required to succeed in the CDS exam and secure a position in the Armed Forces.</p>
     <h4>Why should you join us?</h4>
     <p>Shield Defence college provides extensive training and support, our students have a high success rate in cracking the CDS exam and moving on to become successful officers in the Army, Navy, and Air Force. If you are looking for a challenging and rewarding career in the Armed Forces, then Shield Defence College’s CDS course is the right choice for you. Join us today and take the first step towards realizing your dreams of serving the nation.</p>
     <h3>How to Apply for CDS Examination?</h3>
     <p>The Notification for the CDS written exam is issued in the months of November and July. UPSC holds the exam in the months of Feb and October. Students can apply for the CDS and OTA written examination online only on the UPSC website.</p>
     <p><span>Eligibility for CDS Written Examination</span></p>
     <h4>Educational</h4>
     <p>Candidates who are either qualified or appearing in their final year of graduation are eligible to take the CDS written exam. However, for Air Force and Navy, applicants must have studied engineering, physics, and mathematics. Interested candidates can refer to the official notification for further details. As for OTA, both graduates and final year students are eligible to apply.</p>
     <p>The age requirement for joining IMA is between 19 ½ to 24 years old on the date of joining. For OTA, candidates must be between 19 ½ to 25 years old on the date of joining.</p>
     <p>It is important to note that only male candidates are allowed to take the CDS written exam.</p>
     <h3>Both ladies and men can apply for the OTA exam.</h3>
     <p><span>Exam Pattern of CDS Written Examination</span></p>
     <p>The exam comprises of  three papers:</p>
     <p>General Knowledge – 100 Marks</p>
     <p>English – 100 Marks</p>
     <p>Mathematics – 100 Marks</p>
    </div>
    <div class="courses_inner" id="step3">
     <h2>Syllabus for CDS Written Examination</h2>
     <p>The CDS written exam evaluates candidates in various subjects such as English, History, Polity, Economics, Geography, Mathematics, Life Science, Physics, Chemistry, Current Affairs, and General Knowledge. For the OTA exam, the syllabus is identical to the CDS exam except that OTA candidates are not required to take the mathematics paper.</p>
     <p>The UPSC administers the CDS Written Examination twice a year for graduates to apply for vacancies in the Indian Armed Forces institutions listed below.</p>
     <ul class="dtl_list">
      <li><span>Indian Military Academy (IMA) ; Dehradun</span></li>
      <li><span>Indian Naval Academy; Ezhimala</span></li>
      <li><span>Air Force Academy; Hyderabad</span></li>
      <li><span>Officers Training Academy (OTA); Chennai. For both Men and Women</span></li>
     </ul>
    </div>
   </div>

   <div class="col-lg-3 col-md-3 col-sm-12 col-12">
   
    <?php echo $__env->make('include.side-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </div>
  </div>
 </div>
</div>



<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Request Call Back Section End Here -->



<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>

<!-- <script>
window.onscroll = function() {myFunction()};
var courses_target = document.getElementById("courses_feature");
var sticky = courses_target.offsetTop;
function myFunction() {
  if (window.pageYOffset > sticky) {
    courses_target.classList.add("sticky");
  } else {
    courses_target.classList.remove("sticky");
  }
}
</script> -->
</body>
</html><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/cds-coaching-in-lucknow.blade.php ENDPATH**/ ?>