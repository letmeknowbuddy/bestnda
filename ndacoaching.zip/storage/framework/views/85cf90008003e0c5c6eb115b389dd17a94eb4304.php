<header id="header"> <img id="button-menu" src="images/inner-favicon.webp" alt="Vairagi Ayurveda" />
 <ul class="nav pull-right logout">
  <li><a href="#" class="dropdown-toggle" title="User Name"><i class="fas fa-user"></i> &nbsp;Jhon</a></li>
  <li><a href="login.php" class="dropdown-toggle" title="Log Out"><i class="fas fa-sign-out-alt"></i></a></li>
 </ul>
</header><?php /**PATH C:\xampp\htdocs\shd\resources\views/admin/include/header.blade.php ENDPATH**/ ?>