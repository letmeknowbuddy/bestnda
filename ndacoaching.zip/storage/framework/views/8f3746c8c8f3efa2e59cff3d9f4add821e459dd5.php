<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>Library | Shield Defence College</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<META NAME="GOOGLEBOT" content="NOINDEX, NOFOLLOW" />
<meta name="yahooSeeker" content="noindex, nofollow" />
<meta name="msnbot" content="noindex, nofollow" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section library_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>Library</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Library</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="normal_content">
 <div class="container">
  <div class="row">
   <div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="nor_cont_inner">
     <h2>Library</h2>
     <p>Mind is the weapon of an officer, at Shield Defence College, best coaching institute for NDA and CDS, have a Library with literature across every domain to help the aspirants feed their minds offering a wide range of reading and study material for our students. More than 5,000 reading books and reference books are present in the library. The library is also provided with an internet facility for enhancing the reading habit of every SDCian.</p>
     <p>Mind is the weapon of an officer, at Shield Defence College, best coaching institute for NDA and CDS, have a Library with literature across every domain to help the aspirants feed their minds offering a wide range of reading and study material for our students. More than 5,000 reading books and reference books are present in the library. The library is also provided with an internet facility for enhancing the reading habit of every SDCian.</p>
     <p>Some common features of a Shield Defence College library are :</p>
     <h3>A Collection of defence-related materials:</h3>
     <p>Shield Defence College library typically have a comprehensive collection of resources related to defence and military studies, including topics such as strategy, warfare, leadership, history, technology, and international relations.</p>
     <h3>Digital resources:</h3>
     <p>Shield Defence College library provide access to digital resources such as online databases, e-journals, e-books, and other electronic resources that can be accessed remotely by students and faculty.</p>
     <h3>Specialized collections:</h3>
     <p>Shield Defence College library also have specialized collections such as archives, rare books, maps, and other unique resources that are relevant to defence and military studies.</p>
     <h3>Study spaces:</h3>
     <p>Shield Defence College library typically provide quiet study spaces for students to conduct research, study, and collaborate on academic projects. These spaces may include individual study carrels, group study rooms, and computer labs.</p>
     <h3>Research assistance:</h3>
     <p>Shield Defence College library have librarians and staff who provide research assistance, including help with finding and accessing relevant resources, research guidance, and citation management.</p>
     <h3>Interlibrary loan services:</h3>
     <p>Shield Defence College library also have interlibrary loan services that allow students and faculty to request resources from other libraries if they are not available in the local library’s collection.</p>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Normal Content Section End Here -->


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/library.blade.php ENDPATH**/ ?>