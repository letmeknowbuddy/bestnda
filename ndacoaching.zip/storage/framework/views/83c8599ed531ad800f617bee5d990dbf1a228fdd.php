<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>Hostel & Mess | Shield Defence College</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<META NAME="GOOGLEBOT" content="NOINDEX, NOFOLLOW" />
<meta name="yahooSeeker" content="noindex, nofollow" />
<meta name="msnbot" content="noindex, nofollow" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section hostel_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>Hostel & Mess</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Hostel & Mess</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="normal_content">
 <div class="container">
  <div class="row">
   <div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="nor_cont_inner">
     <p><span>“BREAKING BREAD TOGETHER”</span></p>
     <p>Shield Defence College, the best coaching institute in Lucknow provides hostel and mess services that are designed to provide students with a comfortable and conducive living environment during their time at our defence academy. The mess at Shield defence College, the best defence academy in Lucknow, stands apart from its unique feature of <span>‘Dining Hall’,</span> where every cadet sits and eats together. The mess of SDC can consider over 200 cadets at a time.</p>
     <h3>Hostel Facilities:</h3>
     <p>We understand that a comfortable and safe living environment is essential for your well-being and academic success. Our hostel facilities are well-maintained and equipped with modern amenities to ensure that you have a pleasant stay. We offer separate hostels for male and female students, with adequate security measures in place to ensure your safety. Our hostels are furnished with beds, study tables, chairs, cupboards, and other essential amenities to make your stay convenient and comfortable. We also have common areas and recreational facilities where you can relax, interact with fellow students, and engage in recreational activities.</p>
     <h3>Mess Services:</h3>
     <p>At Shield Defence College,the best defence institute, we recognize the importance of a healthy and nutritious diet in maintaining your physical and mental well-being. Our mess services are designed to provide you with nutritious meals that cater to diverse dietary requirements. We have a well-equipped mess facility that follows strict hygiene and quality standards to ensure that you receive safe and delicious food. Our mess menu includes a variety of vegetarian and non-vegetarian options, and we strive to offer a balanced and wholesome diet that meets your nutritional needs. We also take feedback from students regularly to improve the quality of our mess services.</p>
     <p>In addition to hostel and mess services, we also have dedicated staff who are available round-the-clock to provide support and assistance to students, ensuring a safe and conducive living environment. We understand that living away from home can be a challenging experience, and we are committed to providing you with a supportive and inclusive community where you can thrive academically and personally.</p>
     <p>I encourage all students to take advantage of the hostel and mess services offered at our defence Institute and make the most of their time here. Our aim is to create a comfortable and conducive environment that enables you to focus on your studies and personal growth. Should you have any questions or concerns regarding hostel or mess services, our dedicated staff is always available to assist you.</p>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Normal Content Section End Here -->


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/hostel-mess.blade.php ENDPATH**/ ?>