<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.webp">
<title>AFCAT Coaching in Lucknow | Best AFCAT Classes</title>
<meta name="keyword" content="AFCAT Coaching in Lucknow | Best AFCAT Classes" >
<meta name="description" content="Looking for the best AFCAT coaching in Lucknow? Look no further! Our expert coaches provide comprehensive training to help you ace the AFCAT exam."/>
<link rel="canonical" href="https://shielddefencecollege.com/ssb-coaching-in-lucknow/" />
<meta name="ROBOTS" content="index, follow" />
<META NAME="GOOGLEBOT" content="index, follow" />
<meta name="yahooSeeker" content="index, follow" />
<meta name="msnbot" content="index, follow" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="AFCAT Coaching in Lucknow | Best AFCAT Classes" />
<meta property="og:description" content="Looking for the best AFCAT coaching in Lucknow? Look no further! Our expert coaches provide comprehensive training to help you ace the AFCAT exam." />
<link rel="canonical" href="https://shielddefencecollege.com/ssb-coaching-in-lucknow/" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-04-17T13:34:15+05:30" />
<meta property="og:image" content="https://shielddefencecollege.com/wp-content/uploads/ndabn001.jpg" />
<meta property="og:image:secure_url" content="https://shielddefencecollege.com/wp-content/uploads/ndabn001.jpg" />
<meta property="og:image:width" content="1600" />
<meta property="og:image:height" content="505" />
<meta property="og:image:alt" content="nda coaching in lucknow" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-18T13:50:40+05:30" />
<meta property="article:modified_time" content="2023-04-17T13:34:15+05:30" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="AFCAT Coaching in Lucknow | Best AFCAT Classes" />
<meta name="twitter:description" content="Looking for the best AFCAT coaching in Lucknow? Look no further! Our expert coaches provide comprehensive training to help you ace the AFCAT exam." />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/ndabn001.jpg" />
<meta name="twitter:label1" content="Time to read" />
<meta name="twitter:data1" content="12 minutes" />
<!-- SEO Rank End Here -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">

</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section afcat_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>Air Force Common Admission Test</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Air Force Common Admission Test</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="courses_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-lg-9 col-md-9 col-sm-12 col-12">
    <div class="courses_target" id="courses_feature">
     <ul>
      <li><a href="#step1">Information</a></li>
      <li><a href="#step2">About</a></li>
      <li><a href="#step3">Exam Pattern</a></li>
      <li><a href="#step4">Fees Details</a></li>
      <li><a href="#step5">Exam Syllabus</a></li>
     </ul>
    </div>
    <div class="courses_inner" id="step1">
     <span>(AFCAT COURSE)</span>
     <h2>Air Force Common Admission Test</h2>
     <p>Best AFCAT College in Lucknow, Shield Defence College is the best College for AFCAT exam. AFCAT (Air Force Common Admission Test) is an exam which can give you wings! For all of you who have the dream of working between the sprawling jets can turn this dream into reality through this exam. Air Force Common Admission Test is a written exam conducted by Indian Air Force twice every year to induct officers in the IAF. The written exam is followed by Air Force Selection Board Interview for shortlisted candidates.</p>
     <p>Best AFCAT College in Lucknow, Shield Defence College fuel the jet of aspirants dream. We at Shield Defence College the best College for afcat in Lucknow provide these aspirants with all the paraphernalia that he would need to overcome this grave obstacle of a test with flying colours.</p>
     <p>We boast about us being the best College for defence exams due to our handpicked instructors who themselves burn the midnight oil to get the latest information and know how to do the herculean task of beating this examination. Best Defence College In Lucknow is here to help you. Join Shield Defence College now.</p>
    </div>
    <div class="courses_inner" id="step2">
     <h2>AFCAT</h2>
     <p>Shield Defence College’s AFCAT (Air Force Common Admission Test) course is a comprehensive program designed to help students prepare for the AFCAT exam, which is a gateway to becoming an officer in the Indian Air Force. Our program is designed to provide students with a strong foundation in the subjects required for the exam, including mathematics, English, and general knowledge.</p>
     <h3>Why should you join Shield Defence college for AFCAT?</h3>
     <p>Our experienced faculty and trainers have a deep understanding of the AFCAT exam and provide personalized attention and guidance to each student. Our program covers all aspects of the exam, including verbal ability, numerical ability, reasoning, and general awareness.</p>
     <p>Joining Shield Defence College’s AFCAT course is an excellent opportunity for students who are passionate about serving their country and aspire to become officers in the Indian Air Force. Our program is designed to provide students with the knowledge, skills, and confidence required to succeed in the AFCAT exam and secure a position in the Air Force.</p>
     <p>With our extensive training and support, our students have a high success rate in cracking the AFCAT exam and moving on to become successful officers in the Indian Air Force. If you are looking for a challenging and rewarding career in the Armed Forces, then Shield Defence College’s AFCAT course is the right choice for you.</p>
     <h3>Exam Pattern of AFCAT 2023 Written Examination</h3>
     <p>Indian Men and Women applying for the examination should ensure that to be part of this elite force requires excellence and high quality perseverance towards your physical and internal well being.</p>
     <p>Joining the AirForce as Group A Gazetted Officers in Flying and Ground Duty( Technical andNon-Technical) branches provides all the action and adventure and a lot of trouble towards academic hobbies. From the moment you’re named, till the time you retire, you’re continuously honing your chops with a large number of in- service courses and other educational avenues.</p>
    </div>
    <div class="courses_inner" id="step3">
     <h2>AFCAT Exam Pattern</h2>
     <p><span>The subjects, the time allowed and the maximum marks allotted to each subject will be as follows:-</span></p>
     <div class="courses_table">
      <table>
       <thead>
         <tr>
          <th>Exam</th>
          <th>Subject</th>
          <th>Duration</th>
          <th>No. of Questions</th>
          <th>Max. Marks</th>
          <th>Marks for Correct Answer</th>
          <th>Marks for Incorrect Answer</th>
         </tr>
       </thead>
       <tbody>
        <tr>
         <td>AFCAT</td>
         <td>General Awareness, Verbal Ability in English, Numerical Ability and Reasoning and Military Aptitude Test</td>
         <td>2 Hours</td>
         <td>100</td>
         <td>300</td>
         <td>+ 3</td>
         <td>-1</td>
        </tr>
        <tr>
         <td>EKT [For Candidates with one of the choices as (Technical) Branch]</td>
         <td>Mechanical, Computer Science and Electrical & Electronics</td>
         <td>45 Minutes</td>
         <td>50</td>
         <td>150</td>
         <td>+ 3</td>
         <td>-1</td>
        </tr>
       </tbody>
      </table>
     </div>
     <h3>Exam Pattern of AFCAT Common Paper</h3>
     <div class="courses_table">
      <table>
       <thead>
         <tr>
          <th>Section</th>
          <th>Questions</th>
          <th>Marks</th>
          <th>Time</th>
         </tr>
       </thead>
       <tbody>
        <tr>
         <td>General Awareness</td>
         <td>20</td>
         <td>60</td>
         <td rowspan="4" class="text-center">2 Hours</td>
        </tr>
        <tr>
         <td>Verbal Ability in English</td>
         <td>30</td>
         <td>90</td>
        </tr>
        <tr>
         <td>Numerical Ability</td>
         <td>15</td>
         <td>45</td>
        </tr>
        <tr>
         <td>Reasoning and Military Aptitude Test</td>
         <td>35</td>
         <td>105</td>
        </tr>
       </tbody>
      </table>
     </div>
    </div>
    <div class="courses_inner" id="step4">
     <h2 class="first_item">FEE DETAILS - AFCAT Course Fees Details</h2>
     <div class="courses_table">
      <table>
       <thead>
         <tr>
          <th>Course</th>
          <th>Duration</th>
          <th>Fees</th>
         </tr>
       </thead>
       <tbody>
        <tr>
         <td>AFCAT</td>
         <td>One Year</td>
         <td>-</td>
        </tr>
        <tr>
        <td>AFCAT</td>
         <td>Till Selection</td>
         <td>-</td>
        </tr>
        <tr>
        <td>AFCAT</td>
         <td>Six Months</td>
         <td>-</td>
        </tr>
        <tr>
        <td>AFCAT</td>
         <td>Crash Course</td>
         <td>-</td>
        </tr>
       </tbody>
      </table>
     </div>
    </div>
    <div class="courses_inner" id="step5">
     <h2>AFCAT SYLLABUS</h2>
     <h3>AFCAT EXAM SYLLABUS</h3>
     <p><span>The AFCAT exam comprises various subjects and topics that are as follows:</span></p>
     <h4>AFCAT Exam Syllabus: English</h4>
     <ul class="dtl_list">
       <li>Comprehension</li>
       <li>Error Detection</li>
       <li>Sentence Completion/ Filling in the correct word</li>
       <li>Synonyms</li>
       <li>Antonyms</li>
       <li>Testing of Vocabulary</li>
       <li>Idioms and Phrases</li>
     </ul>
     <h4>AFCAT Exam Syllabus: General Awareness</h4>
     <ul class="dtl_list">
      <li>History</li>
      <li>Geography</li>
      <li>Civics</li>
      <li>Politics</li>
      <li>Current Affairs</li>
      <li>Environment</li>
      <li>Basic Science</li>
      <li>Defense</li>
      <li>Art</li>
      <li>Culture</li>
      <li>Sports</li>
     </ul>
     <h4>AFCAT Exam Syllabus: Numerical Ability</h4>
     <ul class="dtl_list">
      <li>Decimal Fraction</li>
      <li>Time and Work</li>
      <li>Average</li>
      <li>Profit & Loss</li>
      <li>Percentage</li>
      <li>Ratio & Proportion</li>
      <li>Simple Interest</li>
      <li>Time & Distance (Trains/Boats & Streams)</li>
     </ul>
     <h4>AFCAT Exam Syllabus: Reasoning and Military Aptitude Test- Verbal Skills and Spatial Ability</h4>
     <ul class="dtl_list">
      <li>Odd One Out</li>
      <li>Analogy</li>
      <li>Venn Diagram</li>
      <li>Pattern Completion</li>
      <li>Dot Situation Analysis</li>
      <li>Blood Relation</li>
      <li>Missing Figures</li>
      <li>Coding and Decoding</li>
      <li>Spotting the Embedded Figures</li>
      <li>Sequencing</li>
     </ul>
     <h3>AFCAT EKT Syllabus</h3>
     <h4>AFCAT Fundamental Engineering</h4>
     <ul class="dtl_list">
      <li>Engineering Physics</li>
      <li>Engineering Mathematics</li>
      <li>Engineering Drawing</li>
     </ul>
     <h4>AFCAT EKT Allied Engineering</h4>
     <ul class="dtl_list">
     <li>Control Engineering</li>
     <li>Telecommunication Systems</li>
     <li>Electrical Engineering</li>
     <li>Radar Theory</li>
     <li>Instrumentation</li>
     <li>Antenna and Wave Propagation</li>
     <li>Microwave Engineering </li>
     </ul>
     <h4>AFCAT EKT Computer Science Engineering</h4>
     <ul class="dtl_list">
      <li>Information Technology</li>
      <li>Network Theory Design</li>
      <li>Analog and Digital Electronics</li>
      <li>Computer Networks</li>
      <li>Switching Theory</li>
      <li>Electronic Devices</li>
     </ul>
     <h4>AFCAT EKT Mechanical Engineering</h4>
     <ul class="dtl_list">
      <li>Thermodynamics</li>
      <li>Fluid Mechanics/Hydraulic Machines</li>
      <li>Engineering Mechanics</li>
      <li>Materials Science</li>
      <li>Manufacturing Science</li>
      <li>Machine Drawing</li>
     </ul>
     <h4>AFCAT EKT Electrical & Electronics Engineering</h4>
     <ul class="dtl_list">
      <li>Microwave Engineering</li>
      <li>Analog and Digital Electronics</li>
      <li>Electronic Devices</li>
      <li>Telecommunication Systems</li>
      <li>Control Engineering</li>
      <li>Electrical Engineering</li>
     </ul>
    </div>
   </div>

   <div class="col-lg-3 col-md-3 col-sm-12 col-12">
   
    <?php echo $__env->make('include.side-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </div>
  </div>
 </div>
</div>

<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>

<!-- <script>
window.onscroll = function() {myFunction()};
var courses_target = document.getElementById("courses_feature");
var sticky = courses_target.offsetTop;
function myFunction() {
  if (window.pageYOffset > sticky) {
    courses_target.classList.add("sticky");
  } else {
    courses_target.classList.remove("sticky");
  }
}
</script> -->
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/afcat-coaching-in-lucknow.blade.php ENDPATH**/ ?>