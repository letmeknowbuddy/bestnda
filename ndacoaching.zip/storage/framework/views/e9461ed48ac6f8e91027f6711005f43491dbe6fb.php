<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.webp">
<title>Academics | Shield Defence College</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<META NAME="GOOGLEBOT" content="NOINDEX, NOFOLLOW" />
<meta name="yahooSeeker" content="noindex, nofollow" />
<meta name="msnbot" content="noindex, nofollow" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section academics_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>Academics</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Academics</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="normal_content">
 <div class="container">
  <div class="row">
   <div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="nor_cont_inner">
     <h2>Academics of SDC - Best Defence Coaching In India</h2>
     <p>Shield Defence College, best defence coaching in India with boarding believes in incorporating the best technology can offer to make every class-room session a novel and rich learning experience. One of the primary points of focus at Shield Defence College, top defence coaching in Lucknow is to shape and develop future officers in the Armed Forces who live lives of purpose, dignity and prosperity. Learning can never be complete unless individuals inculcate the necessary values of compassion, tolerance, humility, punctuality and perseverance.</p>
     <p>Our Education Branch is headed by our Principal, Captain R J Pandey (Ex-Principal @ Sainik School, Sujanpur, Tira, Himachal Pradesh, Ex-Psychologist – Bhopal) who is both the Academic and Administrative Head of the branch.</p>
     <p>The ‘Academic Block’ is tasked with the primary duty of the academic training of our students and administratively responsible for the following:-</p>
     <ul>
      <li>SDC’ians are put through a teaching schedule of 8 hours each day of classroom learning. Besides they are tasked with doing self study and DPP’s at their cabins in hostel.</li>
      <li>Regular topic based assessments on the cycle of every 6th day and full length mocks on the cycle of 14th day will be conducted.</li>
      <li>Orderly performance evaluation of the students by faculties.</li>
      <li>Academic counseling of the students.</li>
      <li>Monthly and half-yearly PTM’s.</li>
      <li>Publication of the SDC Study Material and SSB Journal.</li>
     </ul>
     <h3>Faculty</h3>
     <p>The teaching faculty of Shield Defence College consists of highly qualified and industrious civilians selected by our Principal and his panel of defence experts. They provide you with the best curriculum and planned strategy to attain a high-profile career in the Indian Armed Forces.</p>
     <p>Our Faculty members actively participate in Faculty Development Meets as mandated by the SDC Management. They keep abreast of the latest developments in their fields and also showcase their scholarship by helping public institute’s training modules and books.</p>
     <h3>Shield Defence Facilities</h3>
     <p>Joining Shield Defence College (SDC) can have a significant impact on the life of a student aspiring to join the Indian Armed Forces. The Academy provides a structured learning environment with expert faculty members who specialize in training students for the SSB NDA exam.</p>
     <p>Shield Defence College (SDC) students are exposed to a rigorous training program that includes Classroom Lectures, Practical Exercises, and Mock Tests. They are also provided with study materials and guidance on how to prepare for the exam.</p>
     <p>Apart from the Academic Training, Students also get to interact with like-minded individuals who share the same passion for serving the nation. This creates a sense of camaraderie and fosters a competitive spirit that motivates students to perform better.</p>
     <p>The Shield Defence College also helps students to develop their personality and communication skills, which are essential for cracking the SSB interview. They are trained on how to present themselves confidently and effectively in front of the interviewers.</p>
     <p>Overall, joining the best SSB NDA Coaching in Lucknow can be a life-changing experience for all aspirants. It not only prepares them for the exam but also helps them to develop the necessary skills and qualities to become successful officers in the Indian Armed Forces.</p>
     <p>Shield Defence College provides a top-notch environment for its students for their overall development. There is a famous saying that <i><b>“Only Work And No Play Makes Jack A Dull Boy</b></i>”. We make sure that we should implement various facilities in our Defence Institute to foster holistic development for the students.</p>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Normal Content Section End Here -->


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/academics.blade.php ENDPATH**/ ?>