<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>Sports & Games | Shield Defence College</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<META NAME="GOOGLEBOT" content="NOINDEX, NOFOLLOW" />
<meta name="yahooSeeker" content="noindex, nofollow" />
<meta name="msnbot" content="noindex, nofollow" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section sports_games_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>Sports & Games</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Sports & Games</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="normal_content">
 <div class="container">
  <div class="row">
   <div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="nor_cont_inner">
     <h2>Sports & Games</h2>
     <p>Being an officer means above all, being a leader of men. Physical Training and Sport facility at SDC is the ideal opportunity for young aspirants to learn important aspects of leadership like courage, stamina, team spirit, physical fitness, mental toughness, and the will to win which is needed by officers. Sports Education has been an integral part of the curriculum at every military training establishment and hence at SHIELD DEFENCE COLLEGE. In the words of Nelson Mandela, “Sport has the power to change the world. It has the power to inspire. It has the power to unite people in a way that little else does. It speaks to youth in a language they understand. Sport can create hope where once there was only despair. It is more powerful than governments in breaking down racial barriers”.</p>
     <p>Keeping in mind the fitness of mind and body. The institute actively involves its students in sports activities with ample space and equipment.</p>
     <ul>
      <li>A newly laid out state of the art green turf is used for football, volleyball and athletics.</li>
      <li>There are other major fields for football, cricket, and other games.</li>
      <li>There is a synthetic plastic-coated basketball court.</li>
      <li>Indoor sports facilities like table tennis room, well equipped gymnasium, and more are available.</li>
      <li>Shooting range and indoor multi–sports complex are the latest additions for the students to stay healthy and fit.</li>
     </ul>
     <p>SDCian are to be trained to play and conduct various games. Each SDCian has to compulsorily participate in at least one Game in his coaching tenure.</p>
     <p>Shield Defense College offers a comprehensive curriculum and gives a strong emphasis on sports and games. Shield Defense College is designed to promote sportsmanship, physical fitness, and teamwork. </p>
     <p>There are a variety of sports and games, including basketball, volleyball, badminton, cricket, table tennis, and athletics. Shield Defense College has a dedicated department for sports and games that train and mentor students. The sports program at Shield Defense College includes inter-college competitions, practice sessions, friendly matches, and national-level tournaments.</p>
     <p>Shield Defense College has a well-equipped gymnasium that helps the fitness needs of students. The gymnasium is instructed by trained fitness instructors. Shield Defense College also has a swimming pool for students.</p>
     <p>Shield Defense College also has Shooting, Archery, and Fencing sports. The College has a separate range for all these sports where students can practice these sports.</p>
     <p>Shield Defense College has a well-balanced sports program that not only promotes physical fitness but also leadership, teamwork, and sportsmanship among students.</p>
     <p>Shield Defense College has skilled coaches and trainers which makes it the best place for students to excel.</p>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Normal Content Section End Here -->


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/sports-games.blade.php ENDPATH**/ ?>