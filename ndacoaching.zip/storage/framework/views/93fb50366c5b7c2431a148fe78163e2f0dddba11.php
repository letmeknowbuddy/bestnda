<header id="header"> <img id="button-menu" src="images/inner-favicon.webp" alt="Vairagi Ayurveda" />
 <ul class="nav pull-right logout">
  <li><a href="#" class="dropdown-toggle" title="User Name"><i class="fas fa-user"></i> &nbsp;<?php echo e(Auth::user()->name); ?></a></li>
  <form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <a href="route('logout')"onclick="event.preventDefault(); this.closest('form').submit();" class="dropdown-toggle" style="padding: 10px 15px;display: block;" title="Log Out"><i class="fas fa-sign-out-alt"></i></a>
    </form>
 </ul>
</header><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/admin/include/header.blade.php ENDPATH**/ ?>