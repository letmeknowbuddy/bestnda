<?php 
$site_update = DB::Table('site_update')->where('id', 1)->first();
?>
<div class="top_bar">
 <div class="container-fluid">
  <div class="row">
   <div class="col-lg-3 col-md-3 col-sm-6 col-12">
    <div class="social_media">
     <ul class="cont_links">
     <li><a href="tel:09140272051"><i class="fas fa-phone"></i> 09140272051</a></li>
     </ul>
    </div>
   </div>
   <div class="col-lg-3 col-md-3 col-sm-6 col-0">
    <p class="limt_seat"><marquee behavior="alternate">Limited Seats! Hurry Up!</marquee></p>
   </div>
   <div class="col-lg-6 col-md-6 col-sm-9 col-12">
    <div class="log_reg">
     <ul>
      <li class="bg-primary"><a href="<?php echo e(route('campus-life')); ?>">Campus Life</a></li>
      <li class="bg-danger"><a href="<?php echo e(route('online-registration')); ?>">Online Registration</a></li>
      <li><a href="<?php echo e(route('fee-payment')); ?>">Online Fee Payment</a></li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>

<header>
 <nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
   <a class="navbar-brand" href="/">
    <img src="<?php echo e(URL::asset('logo/header_image/' .$site_update->logo)); ?>" alt="Shield Defence College" class="normal_logo">
   </a>
   <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
   </button>
   <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
     <li class="nav-item"><a class="nav-link active" aria-current="page" href="/">Home</a></li>
     <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        About Us <i class="fas fa-plus"></i></a>
      <ul class="dropdown-menu">
       <li><a href="<?php echo e(route('our-mission')); ?>" class="dropdown-item">Our Mission</a></li>
       <li><a href="<?php echo e(route ('our-vision')); ?>" class="dropdown-item">Our Vision</a></li>
       <li><a href="<?php echo e(route('our-motto')); ?>" class="dropdown-item">Our Motto</a></li>
       <li><a href="<?php echo e(route('core-values')); ?>" class="dropdown-item">Core Values</a></li>
       <li><a href="<?php echo e(route ('about-us')); ?>" class="dropdown-item">About SDC</a></li>
       <li><a href="<?php echo e(route('chairmans-desk')); ?>" class="dropdown-item">Chairman’s Desk</a></li>
       <li><a href="<?php echo e(route('directors-desk')); ?>" class="dropdown-item">Director’s Desk</a></li>
       <li><a href="<?php echo e(route('principals-desk')); ?>" class="dropdown-item">Principal’s Desk</a></li>
      </ul>
     </li>
     <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
      Courses <i class="fas fa-plus"></i></a>
      <ul class="dropdown-menu">
       <li><a href="<?php echo e(route ('nda-foundation-coaching-in-lucknow')); ?>" class="dropdown-item">NDA Foundation</a></li>
       <li><a href="<?php echo e(route('nda-coaching-in-lucknow')); ?>" class="dropdown-item">NDA</a></li>
       <li><a href="<?php echo e(route('ssb-coaching-in-lucknow')); ?>" class="dropdown-item">SSB Interview</a></li>
       <li><a href="<?php echo e(route('cds-coaching-in-lucknow')); ?>" class="dropdown-item">CDS</a></li>
       <li><a href="<?php echo e(route('afcat-coaching-in-lucknow')); ?>" class="dropdown-item">AFCAT</a></li>
       <li><a href="<?php echo e(route('neet-mns-coaching-in-lucknow')); ?>" class="dropdown-item">NEET + MNS</a></li>
       <li><a href="<?php echo e(route('mns-coaching-in-lucknow')); ?>" class="dropdown-item">MNS</a></li>
      </ul>
     </li>
     <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
      Life @ SDC <i class="fas fa-plus"></i></a>
      <ul class="dropdown-menu">
      <?php 
      $services = DB::table('add_services')->where('status', 0)->where('services_name', 'Life @ SDC')->where('service_name', 'Academics')->first();
      if (!empty($services))
      {
        ?>
        <li><a href="<?php echo e(route('academics')); ?>" class="dropdown-item"><?php echo e($services->service_name); ?></a></li>
        <?php
      }
       ?>

     <?php 
      $services = DB::table('add_services')->where('status', 0)->where('services_name', 'Life @ SDC')->where('service_name', 'GTO & Outdoor Activities')->first();
      if (!empty($services))
      {
        ?>
        <li><a href="<?php echo e(route('gto-outdoor-activities')); ?>" class="dropdown-item"><?php echo e($services->service_name); ?></a></li>
        <?php
      }
       ?>

     <?php 
      $services = DB::table('add_services')->where('status', 0)->where('services_name', 'Life @ SDC')->where('service_name', 'Physical Training')->first();
      if (!empty($services))
      {
        ?>
        <li><a href="<?php echo e(route('physical-training')); ?>" class="dropdown-item"><?php echo e($services->service_name); ?></a></li>
        <?php
      }
       ?>

     <?php 
      $services = DB::table('add_services')->where('status', 0)->where('services_name', 'Life @ SDC')->where('service_name', 'Sports & Games')->first();
      if (!empty($services))
      {
        ?>
        <li><a href="<?php echo e(route('sports-games')); ?>" class="dropdown-item"><?php echo e($services->service_name); ?></a></li>
        <?php
      }
       ?>    

     <?php 
      $services = DB::table('add_services')->where('status', 0)->where('services_name', 'Life @ SDC')->where('service_name', 'Co-curricular')->first();
      if (!empty($services))
      {
        ?>
        <li><a href="<?php echo e(route('co-curricular')); ?>" class="dropdown-item"><?php echo e($services->service_name); ?></a></li>
        <?php
      }
       ?>      
      </ul>
     </li>
     <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
      Cadets’ Corner <i class="fas fa-plus"></i></a>
      <ul class="dropdown-menu">
       <li><a href="<?php echo e(route('hostel-mess')); ?>" class="dropdown-item">Hostel & Mess</a></li>
       <li><a href="<?php echo e(route('uniform-for-sdcians')); ?>" class="dropdown-item">Uniform for SDC’ians</a></li>
       <li><a href="<?php echo e(route('library')); ?>" class="dropdown-item">Library</a></li>
       <li><a href="<?php echo e(route('computer-lab')); ?>" class="dropdown-item">Computer Lab</a></li>
       <li><a href="<?php echo e(route('vikram-batra-auditorium')); ?>" class="dropdown-item">Vikram Batra Auditorium</a></li>
      </ul>
     </li>
     <li class="nav-item"><a class="nav-link" href="<?php echo e(route('our-results')); ?>">Results</a></li>
     <li class="nav-item"><a class="nav-link" href="<?php echo e(route('blog')); ?>">Blog</a></li>
     <li class="nav-item"><a class="nav-link" href="<?php echo e(route('contact-us')); ?>">Contact Us</a></li>
    </ul>
   </div>
  </div>
 </nav>
</header><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/include/header.blade.php ENDPATH**/ ?>