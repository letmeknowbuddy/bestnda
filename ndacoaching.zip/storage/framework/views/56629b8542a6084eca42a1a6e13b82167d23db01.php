<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.webp">
<title>Best NDA Coaching in Lucknow | Best Defence Coaching - Shield Defence College</title>
<meta content="Best NDA Coaching in Lucknow | Best Defence Coaching - Shield Defence College" name="keywords">
<meta content="Shield Defence College is a Best NDA and CDS Coaching in Lucknow offers Best Defence Coaching for NDA, CDS, AFCAT, MNS Exam." name="description">
<link rel="canonical" href="https://shielddefencecollege.com/">
<link rel="amphtml" href="https://shielddefencecollege.com/">
<link rel="alternate" href="https://shielddefencecollege.com/" hreflang="en-us">
<meta name="google-site-verification" content="/">
<meta name="yandex-verification" content="/">
<meta name="ROBOTS" content="INDEX, FOLLOW">
<META NAME="GOOGLEBOT" content="INDEX, FOLLOW">
<meta name="yahooSeeker" content="index, follow">
<meta name="msnbot" content="index, follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Shield Defence College">
<meta property="og:title" content="Best NDA Coaching in Lucknow | Best Defence Coaching - Shield Defence College" />
<meta property="og:description" content="Shield Defence College is a Best NDA and CDS Coaching in Lucknow offers Best Defence Coaching for NDA, CDS, AFCAT, MNS Exam." />
<meta property="og:url" content="https://shielddefencecollege.com/" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:image" content="/" />
<meta property="og:image:secure_url" content="/" />
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="600" />
<meta property="og:image:alt" content="NDA Coaching in Lucknow" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-04T00:28:23+05:30" />
<meta property="article:modified_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:ttl" content="345600">
<meta property="fb:profile_id" content="/">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="/">
<meta name="twitter:creator" content="/">
<meta name="twitter:title" content="Best NDA Coaching in Lucknow | Best Defence Coaching - Shield Defence College" />
<meta name="twitter:description" content="Shield Defence College is a Best NDA and CDS Coaching in Lucknow offers Best Defence Coaching for NDA, CDS, AFCAT, MNS Exam." />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/Shield-Defence-Logo-3.jpg" />
<meta name="twitter:label1" content="Written by" />
<meta name="twitter:data1" content="Sdacollege" />
<meta name="twitter:label2" content="Time to read" />
<meta name="twitter:data2" content="1 minute" />
<meta property="og:updated_time" content="2021-01-06T13:49:21">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="cont_form_section fee_form_section equal_space">
 <div class="container">
  <div class="row">
   <div class="col-lg-8 col-md-6 col-sm-12 col-12">
    <div class="cont_form">
     <h5>FEE PAYMENT</h5>
     <?php if(session('message')): ?>
  <div class="alert alert-success" role="alert">
   <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>
     <span></span>
     <p><strong>Note</strong> :- Please enter your correct email id because your payment invoice sent your email id. Thank You!</p>
     <form method="POST" action="<?php echo e(route('admin.savefess')); ?>">
      <?php echo csrf_field(); ?>
      <div class="row">
       <div class="col-lg-6 col-md-12 col-sm-6 col-12">
        <input type="text" name="name" class="form-control" placeholder="Enter Your Name*" required="">
       </div>
       <div class="col-lg-6 col-md-12 col-sm-6 col-12">
        <input type="email" name="email" class="form-control" placeholder="Enter Your E-mail*" required="">
       </div>
       <div class="col-lg-6 col-md-12 col-sm-6 col-12">
        <input type="number" name="mobile_no" class="form-control" placeholder="Enter Mobile No.*" required="">
       </div>
       <div class="col-lg-6 col-md-12 col-sm-6 col-12">
        <input type="text" name="address" class="form-control" placeholder="Enter Your Address*" required="">
       </div>
       <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <select class="form-control" placeholder="--Select Courses --" name="course">
         <option value="--Select Courses --">--Select Courses --</option>
         <option value="NDA Foundation">NDA Foundation</option>
         <option value="NDA">NDA</option>
         <option value="SSB Interview">SSB Interview</option>
         <option value="CDS">CDS</option>
         <option value="AFCAT">AFCAT</option>
         <option value="NEET+MNS">NEET+MNS</option>
        </select>
       </div>
       <div class="col-lg-4 col-md-12 col-sm-5 col-12">
        <input type="text" class="form-control" name="inr" placeholder="Currency (INR)" >
       </div>
       <div class="col-lg-8 col-md-12 col-sm-7 col-12">
        <input type="number" name="payable_amount" class="form-control" placeholder="Payable Amount (Ex-₹10000)" value="(Ex-₹10000)" required="">
       </div>
       <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <textarea name="message" id="/" class="form-control" rows="3" placeholder="Enter your Message"></textarea>
       </div>
       <div class="col-lg-12 col-md-12 col-sm-12 col-12">
        <input type="checkbox" name="fee_check" value="All above information is correct.">
        <label for="All above information is correct.">All above information is correct.</label>
       </div>
       <div class="col-md-12">
        <button type="submit" name="submit" class="form-control last_inner">Continue to payment</button>
       </div>
      </div>
     </form>
    </div>
   </div>
   <div class="col-lg-4 col-md-6 col-sm-12 col-12">
    <div class="fee_img">
     <img src="website/images/fee-pay-img.webp" alt="Online Fee Payment" class="img-fluid" />
    </div>
   </div>
  </div>
 </div>
</div>


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/fee-payment.blade.php ENDPATH**/ ?>