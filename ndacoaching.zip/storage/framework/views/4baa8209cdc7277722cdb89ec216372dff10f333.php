<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="website/images/favicon.webp">
<title>Computer Lab | Shield Defence College</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<META NAME="GOOGLEBOT" content="NOINDEX, NOFOLLOW" />
<meta name="yahooSeeker" content="noindex, nofollow" />
<meta name="msnbot" content="noindex, nofollow" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
</head>
<body>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="banner-section computer_lab_banner">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <div class="banner_inner">
     <h1>Computer Lab</h1>
     <ul>
      <li><a href="index.php">Home</a></li>
      <li class="lst_sep"> » </li>
      <li>Computer Lab</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Banner Section End Here -->

<div class="normal_content">
 <div class="container">
  <div class="row">
   <div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="nor_cont_inner">
     <h2>Computer Lab</h2>
     <p>Welcome to Shield Defence College computer lab! This high-tech facility is designed to support the academic and research needs of our students and faculty in the field of defence and national security. As a cutting-edge computer lab, we provide advanced computing resources, software, and technical support to facilitate learning and research in various areas, including cybersecurity, military simulations, data analysis, and strategic planning.</p>
     <h3>Facilities and Resources:</h3>
     <p>State-of-the-art Computers: Our computer lab is equipped with the latest hardware, including high-performance desktop computers and servers, optimized for demanding computational tasks.</p>
     <ul>
      <li>We provide access to a wide range of specialized software, including cybersecurity tools, data analysis software, military simulations, and strategic planning software, to support research and learning in defence-related disciplines.</li>
      <li>Our lab is connected to a high-speed internet network, enabling students and faculty to access online resources, conduct research, and collaborate with experts from around the world.</li>
      <li>As the top defence academy in Lucknow, we prioritize cybersecurity. Our lab is equipped with advanced security measures to protect against cyber threats, including firewalls, antivirus software, and regular security updates, to ensure a safe computing environment.</li>
      <li>Our lab has dedicated technical support staff who are available to assist with troubleshooting, software installations, and general technical assistance to ensure the smooth operation of the lab.</li>
      <li>The computer lab serves as a hub for research activities related to defence and national security. Students and faculty can leverage the lab’s resources to conduct cutting-edge research, analyze data, and develop innovative solutions for defence challenges.</li>
      <li>The lab also provides collaborative spaces where students and faculty can work together on group projects, discuss research ideas, and engage in interdisciplinary discussions related to defence and national security.</li>
     </ul>
     <h3>Computer Lab Rules and Regulations:</h3>
     <p>To ensure a productive and secure environment, the computer lab has specific rules and regulations, including</p>
     <ul>
      <li>Access to the computer lab may be restricted to authorized personnel only, and users may be required to log in using their credentials to ensure accountability and security.</li> 
      <li>Users are required to comply with all applicable Shield Defence College policies, including those related to cybersecurity, data privacy, and acceptable use of computing resources.</li>
      <li>To maintain a clean and safe computing environment, no food or drink may be consumed inside the lab.</li>
      <li>Users are required to properly log out of their accounts and shut down the computers after use to ensure security and conserve resources.</li>
      <li>Users are expected to show respect for fellow lab users by maintaining a quiet and respectful environment conducive to learning and research.</li>
      <li>Users are responsible for backing up their data and storing it securely. Lab resources may have limitations on storage space and data retention, and users are encouraged to follow data backup and storage best practices.</li>
      <li>We hope you have a productive and enriching experience at our defence institute computer lab. If you have any questions or need assistance, feel free to reach out to our lab staff. Happy computing!</li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Normal Content Section End Here -->


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\project\routes\resources\views/computer-lab.blade.php ENDPATH**/ ?>