<?php
$webmaster_update  = DB::Table('webmaster_update')->where('id', 1)->first();
$analytics_update  = DB::Table('analytics_update')->where('id', 1)->first();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="wesite/images/favicon.webp">
<title>Our Results - Shield Defence College</title>
<meta content="Our Results - Shield Defence College" name="keywords">
<meta content="Our Results - Shield Defence College" name="description">
<link rel="canonical" href="<?php echo e(URL::current()); ?>">
<link rel="amphtml" href="<?php echo e(URL::current()); ?>">
<link rel="alternate" href="<?php echo e(URL::current()); ?>" hreflang="en-us">
<meta name="google-site-verification" content="<?php echo $webmaster_update->google ?>" />
<meta name="yandex-verification" content="<?php echo $webmaster_update->yandex ?>" />
<!-- <meta name="msvalidate.01" content="<?php echo $webmaster_update->pintrest ?>" /> -->
<meta name="ROBOTS" content="INDEX, FOLLOW">
<META NAME="GOOGLEBOT" content="INDEX, FOLLOW">
<meta name="yahooSeeker" content="index, follow">
<meta name="msnbot" content="index, follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Shield Defence College">
<meta property="og:title" content="Our Results - Shield Defence College" />
<meta property="og:description" content="Our Results - Shield Defence College" />
<meta property="og:url" content="<?php echo e(URL::current()); ?>" />
<meta property="og:site_name" content="Shield Defence College Lucknow - SDC" />
<meta property="og:updated_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:image" content="/" />
<meta property="og:image:secure_url" content="/" />
<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="600" />
<meta property="og:image:alt" content="Our Results" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="article:published_time" content="2023-01-04T00:28:23+05:30" />
<meta property="article:modified_time" content="2023-05-02T14:53:07+05:30" />
<meta property="og:ttl" content="345600">
<meta property="fb:profile_id" content="/">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="/">
<meta name="twitter:creator" content="/">
<meta name="twitter:title" content="Our Results - Shield Defence College" />
<meta name="twitter:description" content="Our Results - Shield Defence College" />
<meta name="twitter:image" content="https://shielddefencecollege.com/wp-content/uploads/Shield-Defence-Logo-3.jpg" />
<meta name="twitter:label1" content="Written by" />
<meta name="twitter:data1" content="Sdacollege" />
<meta name="twitter:label2" content="Time to read" />
<meta name="twitter:data2" content="1 minute" />
<meta property="og:updated_time" content="2021-01-06T13:49:21">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/responsive.css')); ?>">
<?php echo $analytics_update->header; ?>

</head>
<body>
<?php echo $analytics_update->body; ?>

<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clear"></div><!-- Clear End Here -->
<!-- Header Section End Here -->

<div class="our_results equal_space">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <h1 class="text-center main_heading">Our <span>Results</span></h1>
   </div>
  </div>
  <div class="row">
   <div class="col-md-4 col-sm-6 col-12">
    <a href="website/images/results/result1.webp">
     <img src="website/images/results/result1.webp" alt="/" class="img-fluid">
    </a>
   </div>
   <div class="col-md-4 col-sm-6 col-12">
    <a href="website/images/results/result1.webp">
     <img src="website/images/results/result1.webp" alt="/" class="img-fluid">
    </a>
   </div>
   <div class="col-md-4 col-sm-6 col-12">
    <a href="website/images/results/result1.webp">
     <img src="website/images/results/result1.webp" alt="/" class="img-fluid">
    </a>
   </div>
   <div class="col-md-4 col-sm-6 col-12">
    <a href="website/images/results/result1.webp">
     <img src="website/images/results/result1.webp" alt="/" class="img-fluid">
    </a>
   </div>
   <div class="col-md-4 col-sm-6 col-12">
    <a href="website/images/results/result1.webp">
     <img src="website/images/results/result1.webp" alt="/" class="img-fluid">
    </a>
   </div>
   <div class="col-md-4 col-sm-6 col-12">
    <a href="website/images/results/result1.webp">
     <img src="wesite/images/results/result1.webp" alt="/" class="img-fluid">
    </a>
   </div>
  </div>
 </div>
</div>
<div class="clear"></div><!-- Clear End Here -->
<!-- Our Results Section End Here -->


<?php echo $__env->make('include.request-call-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Request Call Back Section End Here -->

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End Here -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\shd_final\resources\views/our-results.blade.php ENDPATH**/ ?>