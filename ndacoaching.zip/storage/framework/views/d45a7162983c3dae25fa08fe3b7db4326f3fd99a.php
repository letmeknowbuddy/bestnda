<?php 
$socal_updated  = DB::table('socal_updated')->where('id',1)->first();
$site_update = DB::Table('site_update')->where('id', 1)->first();
?>

<footer>
 <div class="container-fluid">
  <div class="row">
   <div class="col-lg-5 col-md-8 col-sm-8 col-12">
    <div class="foot_links about_us_link">
     <img src="<?php echo e(URL::asset('logo/header_image/' .$site_update->logo)); ?>" alt="">
     <p><?php echo e($site_update->about); ?></p>
    </div>
   </div>
   <div class="col-lg-3 col-md-4 col-sm-4 col-12">
    <div class="foot_links site_link">
     <h3>Quick Links</h3>
     <ul>
      <li><a href="<?php echo e(route('about-us')); ?>"><i class="fa-solid fa-angles-right"></i> About Us</a></li>
      <li><a href="<?php echo e(route('blog')); ?>"><i class="fa-solid fa-angles-right"></i> Blog</a></li>
      <li><a href="<?php echo e(route('contact-us')); ?>"><i class="fa-solid fa-angles-right"></i> Contact Us</a></li>
      <li><a href="<?php echo e(route('privacy-policy')); ?>"><i class="fa-solid fa-angles-right"></i> Privacy & Policy</a></li>
      <li><a href="<?php echo e(route('terms-and-conditions')); ?>"><i class="fa-solid fa-angles-right"></i> Terms & Condition</a></li>
     </ul>
    </div>
   </div>
   <div class="col-lg-4 col-md-12 col-sm-12 col-12">
    <div class="foot_links foot_cont">
     <h3>Get in Touch</h3>
     <ul>
      <li><i class="fas fa-location"></i> <span>Gaura, Mohanlalganj, Raebareli Road, Lucknow. 226301</span></li>
      <li><i class="fas fa-phone"></i><a href="tel:09140272051">09140272051</a>,
       <a href="tel:08881444811">08881444811</a>
      </li>
     </ul>
    </div>
    <div class="foot_links social_links">
     <ul>
      <li><a href="<?php echo e($socal_updated->youtube); ?>"><i class="fa-brands fa-youtube"></i></a></li>
      <li><a href="<?php echo e($socal_updated->Facebook); ?>"><i class="fa-brands fa-facebook-f"></i></a></li>
      <li><a href="<?php echo e($socal_updated->intagram); ?>"><i class="fa-brands fa-instagram"></i></a></li>
     </ul>
    </div>
   </div>
  </div>
 </div>
</footer>
<div class="copyright">
 <div class="container">
  <div class="row">
   <div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="copy_inner">
     <p>© 2023 <a href="/">SHIELD DEFENCE COLLEGE</a> All Rights Reserved  | Designed By Balj Services</p>
    </div>
   </div>
  </div>
 </div>
</div><?php /**PATH C:\xampp\htdocs\mohd\bestndacoachinginlucknow_final\resources\views/include/footer.blade.php ENDPATH**/ ?>