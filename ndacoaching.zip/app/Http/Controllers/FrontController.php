<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;

class FrontController extends Controller
{
    public function about()
    { return view('about-us'); }
   
    public function contact ()
    { return view('contact-us'); }



    public function blog()
    {
    $blog = DB::table('add_blog')->where('status', 0)->orderBy('id', 'desc')->get();
    return view('blog', ['blog' => $blog]);
    }

    public function blogdetls($blog_slug)
    {
       $blogs = DB::table('add_blog')->where('status', 0)->orderBy('id', 'desc')->where('blog_slug',$blog_slug)->first();
        if (!empty($blogs)) 
        {
           return view('blog-details',['blogs' => $blogs]);
        }else{

            return redirect('404error');
        }
    }
    
    public function privacy()
    { return view('privacy-policy'); }

    public function terms()
    { return view('terms-and-conditions'); }

     public function eroor()
    { return view('404error'); }
 
}
